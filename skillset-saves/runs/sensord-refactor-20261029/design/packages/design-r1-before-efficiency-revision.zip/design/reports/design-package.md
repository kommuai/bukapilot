---
submission_id: sensord-refactor-20261029-design-r1
revision: r1
owner: commander
---

# Design package — `system/sensord` efficiency refactor

**Boundary:** `design-to-build`  
**Run:** `sensord-refactor-20261029`  
**Package revision:** `r1`

## Outcome and scope

This package specifies a behavior-preserving efficiency refactor inside `system/sensord`. It retains KA2 and TICI/tizi sensor selection, service rates, event fields and timestamps, warmup, calibration results, error handling, IRQ behavior, and shutdown. The design limits implementation to four slices: polling ratekeeping, fixed calculations, gyro calibration-buffer representation, and event-construction sharing only where exact parity is proven.

No schema, topology, bus ownership, thread, register, runtime, framework, dependency, or unrelated change is included. No hardware performance or integration claim is made.

## Design decisions

- **Architecture:** preserve the current process, driver, bus, and worker boundaries. Every polling iteration reaches the existing service `Ratekeeper`, including invalid warmup iterations; invalid events remain unpublished.
- **Numerics:** hoist fixed work while preserving floating-point expression behavior. Keep the ordered signed calibration samples and the existing `statistics.fmean` and population `pstdev` computations.
- **Interfaces:** `change: none`; no new endpoint or service contract. Per-driver event timestamp sources, optional field presence, union, payload order, and status remain explicit.
- **Security:** the security-builder assessment records no trust boundary introduced or moved by this design delta; build security review confirms the implementation remains inside that boundary.
- **Stack:** the typed Commander applicability record uses the sanctioned no-new-runtime/framework reason. The project-wide detector stopped at its byte limit, so no repository stack slug is inferred.
- **Taste:** use the existing immutable no-profile snapshot, validated against store absence, source revisions, resolved entries, applicability, and its canonical digest.
- **Acceptance:** AC-1 through AC-4 are owned by build/build-management and review/code-chief as detailed in the plan. The implementation spec covers all four slice IDs; AC-4 applies to the whole change.

## Delivery shape

M1 paces invalid polling reads; M2 covers fixed calculations and compact gyro samples; M3 shares event construction only for drivers with exact parity; M4 completes scoped offline verification and submits to review. The spec assigns each of the four slices disjoint module ownership and defines its offline proof and rollback. The existing hardware integration test and comparative CPU/RSS measurement are deferred until a target owner identifies a safe KA2/TICI rig and agrees on an appropriate baseline and success threshold.

## Artifact map

All artifact hashes for this revision are bound in `manifest.json`.

| Artifact | Purpose / owner |
| --- | --- |
| `../intake/report_grilling.md` | Admiral-owned decisions and deferrals |
| `reports/requirements-brief.md` | Researched requirements, constraints, and hardware/readiness limitations |
| `reports/report_architecture.md` | Architect-owned boundaries, data flow, invariants, and bounded design |
| `reports/report_interfaces.md` | Architect-owned `change: none` interface contract and UI applicability |
| `reports/report_security-seed.md` | Security-builder assessment for the design delta |
| `reports/delivery-plan.md` | Planner-owned milestones, acceptance criteria, rollback, risks, and Decision Register |
| `reports/implementation-spec.md` | Engineer-owned four-slice implementation guidance |
| `reports/report_stack-lock.md` | Commander-owned stack applicability decision and detector limitation |
| `reports/report_taste-snapshot.md` | Taste snapshot validation summary |
| `artifacts/taste_snapshot.json` | Existing immutable Taste no-profile snapshot |

## Open risks and limits

- Six `/dev/i2c-*` character-device paths are present, but board/sensor identity, functional access, and relation to a confirmed KA2/TICI rig remain unknown. No device was accessed and no hardware test was run.
- No target CPU/RSS baseline or quantitative success threshold exists. The intended CPU, memory, and code-size gains remain unmeasured.
- The repository-wide stack scan stopped at its total-byte cap; no stack slug is asserted.
- The available Python 3.12.3 satisfies the repository declaration `>=3.11,<3.13` but is below the harness minimum `>=3.13`; missing Codex hooks are also recorded in intake. The gate commands' actual results determine validation status.

## Phase handoff

The design package is ready for `gatekeeper-design` to judge at `design-to-build`. This document records the submitted scope and evidence; it does not pre-state the gate verdict. A passing design gate returns implementation ownership to Admiral for its cross-stage gate and next handoff.
