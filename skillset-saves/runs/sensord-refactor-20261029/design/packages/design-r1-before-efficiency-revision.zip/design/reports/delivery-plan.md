# Delivery Plan — `system/sensord` efficiency refactor

**Revision:** 1  
**Architecture:** `reports/report_architecture.md` @ `2d5b7466d8cdd7a03281f1e7d268b8de420bb938e362eaebd02b718cff13b6f6`  
**Security seed:** complete; the design assessment found no trust boundary introduced or moved and no additional control work. The build security checkpoint will verify the implementation stays within that assessed boundary.

## Milestone path

| # | Milestone | Delivery slices | Depends on | Decision gate before it | Target |
| - | --- | --- | --- | --- | --- |
| M1 | Pace polling from the first iteration | `slice.sensord.poll-ratekeeper` | Approved architecture; retain each service's configured `Ratekeeper` | Offline test proves every invalid polling iteration is paced and emits no warmup event | First build slice; no date was supplied |
| M2 | Reduce repeated numeric work without changing results | `slice.sensord.fixed-calculations`, `slice.sensord.gyro-buffer` | M1 may land first; both stay within existing driver ownership | Fixed inputs and calibration samples produce the existing numeric outputs and classification | After M1; no date was supplied |
| M3 | Reduce event-construction duplication where exact parity holds | `slice.sensord.event-construction` | Interface report and M2; per-driver event contracts remain explicit | Focused offline comparison proves timestamps, metadata, unions, payloads, status, and unset fields match; otherwise retain local construction | After M2; no date was supplied |
| M4 | Verify the scoped offline change and submit to review | All slices | M1–M3 and the design acceptance table | Affected offline tests pass, `git diff --check` passes, and review confirms only approved paths changed | `build-to-review`; this run stops before merge, release, or hardware rollout |

The order isolates the polling control-flow fix, then numerical transformations and calibration storage, and puts the most contract-sensitive helper last. No milestone changes sensor selection, register settings, bus ownership, thread topology, service cadence, or cereal schema. The security assessment is complete and found no trust-boundary movement or additional control work. The build checkpoint must verify that implementation stays within the seed.

## Acceptance criteria

| ID | Slice | Observable condition | Check that proves it | Acceptor |
| --- | --- | --- | --- | --- |
| AC-1 | `slice.sensord.poll-ratekeeper` | Each invalid polling iteration reaches the existing service `Ratekeeper` once, and no sensor event is published before the current warmup validity window passes. | Focused offline test with invalid sensor data, a recording `Ratekeeper`, and a recording publisher checks keep-time call count and zero warmup sends. | `build/build-management` |
| AC-2 | `slice.sensord.fixed-calculations` and `slice.sensord.gyro-buffer` | Fixed transforms/scales produce the same values; a fixed ordered set of gyro samples produces identical per-axis means, population standard deviations, stationary result, and selected bias. | Focused offline equivalence tests compare the pre-refactor results and the refactored outputs for fixed inputs; the calibration test uses the existing `fmean` and `pstdev` calculations. | `build/build-management` |
| AC-3 | `slice.sensord.event-construction` | Every changed event preserves its driver-specific timestamp source, version, source, sensor/type presence, union, payload values/order, status, and unset defaults. Any driver that cannot meet this condition keeps its local construction. | Focused offline tests compare serialized event fields and field presence for representative drivers and prove the shared helper path only where parity holds. | `build/build-management` |
| AC-4 | All slices | The change stays within the approved `system/sensord` implementation and focused offline tests; it adds no schema, dependency, runtime, bus, sensor, or thread change. The non-test implementation LOC delta is reported, with no numeric reduction threshold invented. | Review the scoped file list and diff; report `git diff --numstat -- system/sensord` and run `git diff --check`. | `review/code-chief` |

Hardware integration tests and comparative CPU/RSS measurements are not acceptance checks for this run. The present I2C node identities, functional sensor access, confirmed KA2/TICI rig, and before/after baseline remain unknown; no device access is authorized by this plan.

## Rollout and rollback shape

| Stage | Audience | Mechanism | Rollback | Trigger to advance |
| --- | --- | --- | --- | --- |
| Offline implementation | Build and review owners | Land the bounded code and focused offline tests in the working branch; preserve existing service behavior | Revert only the scoped `system/sensord` implementation and focused tests | AC-1 through AC-4 pass and the `build-to-review` package is approved |
| Device validation | Deferred target owner | Identify a safe KA2/TICI rig, confirm device access, then run the existing hardware integration checks and gather a comparable CPU/RSS baseline | Not part of this run; determine a target-specific rollback before any hardware rollout | Separate owner decision after hardware identity, access, baseline window, and success threshold are agreed |
| Merge, release, hardware rollout | Out of scope | None in this run | Not applicable | Requires a separate explicit decision after review |

There is no persisted-data migration, schema change, dependency change, or consumer migration in this design. No release date, team-capacity commitment, or operational support window was supplied.

## Risk handling

| Risk | Kind | Consequence if it lands | Mitigation | Owner |
| --- | --- | --- | --- | --- |
| Invalid polling loop still skips `keep_time()` | Technical | Warmup/error cases can consume CPU above the configured service rate | Put pacing on the common loop path and test invalid samples with a recording ratekeeper | `build/build-management` |
| Helper fills fields that current drivers leave unset or changes an ignored timestamp argument | Technical | Published event behavior changes despite unchanged schema | Keep per-driver contract rows; add field-presence and serialized-payload comparisons; leave a driver local if parity is not exact | `build/build-management` |
| Compact calibration representation changes signed values or ordering | Technical | Floating-point statistics or bias classification can change near existing thresholds | Use a bounded signed-integer representation and prove exact sample order/value plus unchanged `fmean`/`pstdev` outputs | `build/build-management` |
| I2C nodes cannot be tied to a safe KA2/TICI target, or no comparable baseline is available | External | Device behavior and target CPU/RSS effect remain unverified | Do not access devices or claim a speedup; ask the target owner to identify hardware and agree on baseline/success criteria before hardware work | User/target owner with `build/build-management` |
| Harness tooling runs under Python 3.12.3, below its >=3.13 minimum, and Codex hooks are missing | Environment | Some lifecycle validators may be unsupported or entry routing is not hook-enforced | Preserve exact tool outputs, distinguish passing commands from unsupported checks, and have Admiral name any unverified gate evidence; do not change the environment as part of this code scope | Admiral/operator |
| Project-wide stack detection stopped at its byte limit | Environment | No complete repository stack inventory is available from that scan | Do not invent a stack slug; this design introduces no runtime/framework/dependency and Commander records only the sanctioned no-new-runtime applicability | Commander |

## Decision Register

| Decision | Status | Chosen | Source | Rejected options (why) | Owner | Reopen trigger / latest safe point |
| --- | --- | --- | --- | --- | --- | --- |
| D-1: behavior boundary | resolved | Preserve KA2 and TICI/tizi selection, rates, messages, timestamps, warmup, calibration, error handling, IRQ behavior, and shutdown. | user | Any externally visible behavior change violates the approved scope. | `design/commander` | Reopen only with explicit user approval before implementation. |
| D-2: bounded refactor | resolved | Pace invalid polling iterations, hoist fixed work, compact exact calibration samples, and share event construction only where exact defaults remain identical. | delegated-default | Thread/bus consolidation or unrelated cleanup widens risk without being needed for this objective. | `design/commander` | Reopen if implementation requires a new boundary or dependency. |
| D-3: target performance and hardware validation | deferred | Leave CPU/RSS improvement qualitative; defer device checks until the visible nodes are identified, a safe KA2/TICI rig and baseline exist, and a target owner agrees on a success threshold. | user | Treating node presence as a known rig or claiming performance without a baseline is unsupported. | User/target owner with `build/build-management` | Before any device test or target-performance claim. |
| D-4: worker and bus topology | rejected | Keep polling/IRQ workers and driver-owned bus handles as they are. | user | Combining them changes scheduling and bus ownership, outside the requested slice. | `design/commander` | Reopen only under a separately approved architecture revision. |
| D-5: gyro statistics | rejected | Keep `statistics.fmean` and population `pstdev` over the same ordered integer samples. | user | Online estimates can change floating-point accumulation and threshold classification. | `design/commander` | Reopen only with explicit approval and an equivalence plan. |
| D-6: interface, sensor, runtime, and dependency changes | yagni-deferred | No schema, service, sensor, register, bus, runtime, framework, or dependency change. | user | None is required for the scoped refactor. | `design/commander` | Reopen only when a hardware revision or approved interface need requires it. |
| D-7: hardware rollout and quantified speedup | deferred | Stop before hardware rollout and make no measured target-speedup claim. | user | No confirmed hardware identity, access, baseline, or threshold is available. | User/target owner | Before device-level validation, merge, or rollout. |
| D-8: event helper boundary | resolved | Introduce a shared event helper only for drivers whose parity tests prove all currently assigned and unset fields remain exact; otherwise retain those drivers' local code. | codebase | A helper that normalizes defaults or timestamps would change the interface contract. | `build/build-management` | Decide per driver before that driver's helper change is merged into the build slice. |

## Migration / deprecation

Not applicable — nothing existing is removed or replaced; the work preserves the current sensor services and data contract.

## Non-goals and YAGNI deferrals

| Deferred | Why it is safe to defer | Reopen trigger | Owner |
| --- | --- | --- | --- |
| Identify or exercise `/dev/i2c-*` nodes | Their board/sensor identity and functional access are unverified; no confirmed target rig is available. | Target owner identifies a safe KA2/TICI rig and authorizes device validation. | User/target owner |
| Comparative CPU and RSS measurement | A baseline and numeric success threshold were not supplied. | Agree on target, workload, measurement window, and threshold before claiming improvement. | User/target owner with `build/build-management` |
| Change sensor/thread/bus/schema topology | It is explicitly outside the bounded objective and adds behavioral risk. | A separately approved architecture decision demonstrates it is necessary. | `design/commander` |
| Add a new framework, runtime, or dependency | No new stack element is needed for this refactor. | A build blocker requires a new dependency and Admiral obtains explicit approval. | `design/commander` |
