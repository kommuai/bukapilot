# Architecture — `system/sensord` efficiency refactor

**Design revision:** 1  
**Prepared for:** `design/planner` and `design/engineer`  
**Source decisions:** Admiral intake D-1 through D-7; requirements brief revision 3  
**Scope:** behavior-preserving refactor within the existing `sensord` Python service

## Decision summary

Keep the current process boundary, platform selection, I2C bus ownership, sensor-driver responsibilities, polling and interrupt thread topology, cereal service names, and published `SensorEventData` contract. Restrict implementation changes to the existing polling-loop pacing point, fixed per-sample calculations, the ICM42670 gyro calibration sample representation, and shared event construction where each driver's exact field behavior can be retained.

The architecture introduces no new service, schema, runtime, framework, dependency, bus, or thread. It does not promise a measured CPU or RSS gain. The six visible `/dev/i2c-*` character-device paths have not been identified or opened; their board/sensor identity, safe functional access, and relation to a KA2/TICI target remain unknown.

## Current component boundaries

| Component | Current responsibility | Boundary to preserve |
| --- | --- | --- |
| `sensord.main` | Selects KA2 versus TICI/tizi sensor composition, resets and initializes drivers, starts the existing worker threads, and signals/joins/shuts down on exit. | Owns platform selection and process lifecycle; no topology, thread, or bus-sharing change. (`system/sensord/sensord.py:96–162`) |
| `Sensor` base | Owns one `smbus2.SMBus` instance, register reads/writes, signed integer parsing, and the 0.5-second startup-validity window. | Driver instances retain their bus ownership, parsing results, and warmup behavior. (`system/sensord/sensors/i2c_sensor.py:15–36,57–62`) |
| Sensor drivers | Own each device's register configuration, sample conversion, timestamp choice, event union and metadata, and shutdown operations. | Hardware-specific register sequences and per-driver output details stay local and unchanged in meaning. |
| Polling workers | Read a non-interrupt sensor, gate publication on `is_data_valid()`, publish a valid cereal message, and pace using that service's `Ratekeeper`. | Each iteration must reach `keep_time()` whether the reading is invalid, valid, or fails; invalid warmup samples remain unpublished. (`sensord.py:81–94`) |
| Interrupt worker | Reads GPIO 84 events, translates the kernel event timestamp using the realtime/monotonic offset, checks shared data-ready status, and publishes interrupt-driven sensors. | Preserve IRQ edge handling, timestamp-jump behavior, `DataNotReady` suppression, logging, and event-to-sensor mapping. (`sensord.py:28–79`) |
| Cereal subscribers | Consume the existing accelerometer, gyroscope, magnetometer, and temperature services. | No schema, service-name, cadence, union, metadata, or consumer change. (`cereal/services.py:22–30`, `cereal/log.capnp:342–383`) |

## Platform composition and data flow

```mermaid
flowchart LR
  M[ sensord main / platform selection ] --> K[ Sensor drivers and owned I2C buses ]
  K --> P[ Polling workers + Ratekeeper ]
  K --> I[ GPIO 84 interrupt worker ]
  P --> E[ SensorEventData + valid cereal message ]
  I --> E
  E --> C[ PubMaster / existing cereal services ]
  C --> S[ Existing subscribers ]
```

- **KA2:** bus 3; ICM42670 accelerometer, gyro, and temperature plus LIS2MDL magnetometer; all use polling (`sensord.py:26,99–107`).
- **TICI/tizi:** bus 1; LSM6DS3 accelerometer and gyro use the interrupt worker; LSM6DS3 temperature is polled; tizi adds the optional MMC5603 magnetometer (`sensord.py:26,108–119`).
- The configured service frequencies are 104 Hz for accelerometer and gyroscope, 25 Hz for magnetometer, and 2 Hz for temperature (`cereal/services.py:25–29`).
- The shared I2C base parses signed 16-bit and 20-bit register values. Drivers map those values into the existing cereal union and apply the platform-specific transforms.
- ICM42670 gyro initialization collects 300 samples at 5 ms intervals, uses `statistics.fmean` and population `pstdev`, and chooses the measured bias only when the existing mean and standard-deviation thresholds pass (`icm42670_gyro.py:32–35,70–90`).

## Bounded implementation design

1. **Pace invalid polling reads.** Replace the early `continue` after `is_data_valid()` with a publication conditional so every loop reaches the existing `Ratekeeper.keep_time()`. Preserve the ordering of read, validity check, message construction, send, exception logging, and ratekeeping. Do not publish while warmup is invalid. Do not alter the interrupt path.
2. **Hoist fixed transforms and scales.** Compute fixed trigonometric values and constant conversion factors once per module or driver instance. Preserve the existing expression order where floating-point rounding can differ; do not algebraically rewrite conversions without exact-equivalence evidence. Keep source-dependent temperature scaling selected from the existing sensor source.
3. **Reduce calibration storage.** Store each axis's 300 raw `c_int16` samples in a compact signed-integer buffer with verified range and element width. Preserve sample order and integer values, then run the same `fmean` and `pstdev` over each axis and the same threshold/bias decisions. Do not replace these statistics with an online approximation.
4. **Share event construction only behind exact per-driver inputs.** A helper may remove repeated `SensorEventData.new_message()` and assignment scaffolding, but it must accept the driver's timestamp, version, source, optional sensor/type fields, union name, payload, and status explicitly. It must leave fields unset when the current driver leaves them unset and retain each driver's timestamp source. If this helper cannot prove that, keep the event construction local.

No new abstraction is required for bus access, sensor selection, scheduling, or IRQ delivery. In particular, combining workers or sharing bus handles is outside the approved boundary.

## Invariants and failure behavior

- Preserve `KA2` selection, `HARDWARE.get_device_type() == "tizi"` optional magnetometer behavior, bus numbers, addresses, register settings, and initialization order.
- Preserve `is_data_valid()`'s startup window and the absence of publication during warmup.
- Keep per-service `Ratekeeper` pacing for polling. The targeted defect is that the invalid-data `continue` currently bypasses it; exceptions already fall through to `keep_time()`.
- Preserve IRQ timestamp conversion, offset-jump rejection, GPIO line/edge handling, `Sensor.DataNotReady` suppression, and per-service exception logging.
- Preserve per-driver event version, sensor/type assignments, source enum, timestamp source, union variant, payload ordering, status value, and unset defaults. Do not update `cereal/log.capnp`.
- Preserve reset/init/shutdown error logging and the current shutdown loop. Do not make sensor lifecycle conditional on new hardware discovery.

## Security, deployment, and stack boundaries

There is no user-facing surface, HTTP/API endpoint, authentication flow, or remote data path in this change. Sensor registers and the GPIO event descriptor are local hardware inputs; the design leaves their parsing, privilege use, and error handling to existing code. `build/security-builder` still owns the required design security assessment and must decide whether the local hardware boundary needs controls; this report does not substitute that assessment.

The existing managed process and repository packaging remain in place. The scope adds no dependency or runtime/framework. The repository `pyproject.toml` declares Python `>=3.11,<3.13`; the active environment's Python 3.12.3 satisfies that project declaration but is below the harness runtime manifest's 3.13 minimum.

Required detector evidence was collected:

```text
python3 /data/kommu/.codex/skills/scripts/check_runtime.py --project-root /data/openpilot --detect-project
Python: too_old (3.12.3)
Inspecting: /data/openpilot
Inspection: library/CLI; stacks=none; start candidates=0
Inspection error: project inspection total-byte limit exceeded; the walk stopped early and the inspection is incomplete: manifests and stacks beyond that point were not examined (narrow it with --project-root)
Inspection note: no supported runtime classification signal was found
Ready: no
Error: Python 3.12 is below required 3.13
Error: project inspection: project inspection total-byte limit exceeded; the walk stopped early and the inspection is incomplete: manifests and stacks beyond that point were not examined (narrow it with --project-root)
```

A second read-only check scoped to `/data/openpilot/system/sensord` found no project manifest or registered stack under that directory. The root scan is incomplete, so its empty stack list is not evidence that the whole repository has no stack. Commander must not invent a slug or overlay digest; stack-lock applicability is a Commander-owned decision based on the approved no-new-runtime scope and the observable package metadata.

## Alternatives rejected

| Alternative | Decision |
| --- | --- |
| Merge polling and IRQ workers or share bus objects | Rejected by intake D-4; changes scheduling and bus ownership without being necessary for the scoped savings. |
| Replace `fmean`/`pstdev` with online estimates | Rejected by intake D-5; floating-point accumulation may alter threshold classification. |
| Change cereal field defaults, schema, rates, or sensor topology | Rejected by D-1/D-2 and constraints C-1/C-2. |
| Claim hardware speedup from visible I2C device nodes | Not supported: their identity, functional access, test target, and before/after baseline are unverified. |

## Build acceptance evidence

The build phase should provide offline evidence that (a) an invalid polling sample still calls `keep_time()` and emits no event during warmup, (b) event metadata, payload, union choice, and unset defaults match the current drivers, and (c) a fixed gyro sample sequence yields identical means, standard deviations, stationary result, and selected bias. Keep hardware integration and comparative target CPU/RSS measurements deferred until a target owner identifies a safe KA2/TICI rig and establishes a baseline. The implementation has a simple rollback: revert the scoped `system/sensord` source/test change; there is no persisted data or schema migration.

## Open risks and unknowns

- **Info:** six `/dev/i2c-*` paths are present, but their board/sensor identity and functional access are unknown; no device was accessed for this design.
- **Info:** no agreed CPU reduction or RSS threshold exists, so improvement remains qualitative until a target baseline and acceptance window are supplied.
- **Info:** the harness self-check's required Python minimum is unmet, and the repository-wide stack detector stopped at its byte limit. Those are validation environment limits, not product defects.
- **Info:** event construction has intentional per-driver differences; the shared helper is conditional on preserving them exactly and may be dropped if it increases code or obscures defaults.
