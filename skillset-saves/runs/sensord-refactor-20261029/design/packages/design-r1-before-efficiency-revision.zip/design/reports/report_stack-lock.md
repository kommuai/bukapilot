# Stack applicability — sensord efficiency refactor

**Decision owner:** commander  
**Boundary:** design-to-build

## Applicability

This design adds no runtime, framework, or dependency, as required by the intake scope. The sanctioned typed applicability decision is:

```json
{"applicable":false,"reason":"no new runtime or framework - existing stack unchanged","scope":"design-to-build","decided_by":"commander"}
```

## Detection limits

The repository-wide project detector stopped because its total-byte scan limit was reached. The scoped `system/sensord` inspection established no local project manifest or registered stack, but it does not establish a repository-wide stack slug. No slug or version lock is inferred from that incomplete scan.

The inspected root `pyproject.toml` supports Python `>=3.11,<3.13`; host Python 3.12.3 is compatible with the product declaration and below the harness readiness minimum of 3.13. The handoff also reports missing Codex hooks. These are readiness limitations; runtime, framework, dependency, and environment changes are outside this design.

The applicability decision rests on the approved no-new-runtime/framework/dependency scope, not on interpreting the truncated detector output as proof that no stack exists. Any later request to change runtime or dependencies must reopen the stack decision before implementation.
