# Security Seed — `sensord` efficiency refactor

**Phase:** design  
**Return boundary:** `design-to-build`  
**Architecture revision:** 1  
**Assessment owner:** `build/security-builder`

## Assessment

This design introduces or moves no trust boundary. It keeps the existing local I2C and GPIO inputs, parsing, privilege use, and error handling in place. It adds no remote input path, authentication or authorization flow, sensitive-data processing, service, or dependency. The six visible `/dev/i2c-*` paths remain unidentified and were not accessed; their presence does not change the boundary assessment.

The security seed is scoped to the design delta. It is not an audit of the existing sensor-driver implementation. At build time, `security-builder` should confirm the changed code stays within this design and that no trust boundary moved.

## Typed `security_seed`

```yaml
applicable: false
scope: design-to-build
decided_by: security-builder
architecture_revision: "1"
reason: "design introduces or moves no trust boundary; existing local I2C/GPIO handling is unchanged"
boundaries: []
```
