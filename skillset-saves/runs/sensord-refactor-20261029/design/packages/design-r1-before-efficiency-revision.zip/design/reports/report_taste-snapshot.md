# Taste snapshot applicability record

**Owner:** taste  
**Boundary:** design-to-build  
**Snapshot artifact:** `artifacts/taste_snapshot.json`

The existing snapshot has canonical digest `sha256:1beb862ffc2faa7ade5f7b2308f2803bc9cea1981dbf2144ce044fa8ebd9132b`. Its source revisions are global `0` and project `0`; its resolved entries and shadowed entries are empty, and unresolved conflicts are empty. Taste resolved that both stores contain no saved profile, so applicability is false with reason `no saved Taste profile available`, scope `both`, decided by `taste`.

The immutable snapshot was validated and retained without reconstruction from mutable stores. No preference drift is indicated. Blank-store source digests can vary when status is re-read because a generated timestamp participates in the synthetic blank record; validation therefore relies on store absence, zero source revisions, empty resolved entries, and the saved snapshot's canonical digest. The snapshot file's content hash is recorded in the design manifest.
