# Interface contract — `system/sensord` efficiency refactor

**Design revision:** 1  
**Boundary:** `design-to-build`  
**Contract result:** `change: none`

## Interface inventory

There is no request/response API, webhook, or user-facing endpoint in scope. `sensord` reads local I2C/GPIO inputs and publishes through `cereal.messaging.PubMaster` under the existing service names (`system/sensord/sensord.py:28–79,81–94`). Every published message is created with top-level `valid=True`; this stays unchanged. The design changes internal polling pacing and event construction only. It does not change the service or the serialized `SensorEventData` contract (`cereal/log.capnp:342–383`).

| Service | Cadence | Existing payload union | Existing source behavior |
| --- | ---: | --- | --- |
| `accelerometer` | 104 Hz | `acceleration` with `v` and status | ICM42670 on KA2; LSM6DS3/LSM6DS3TRC on TICI/tizi. |
| `gyroscope` | 104 Hz | `gyroUncalibrated` with `v` and status | ICM42670 on KA2; LSM6DS3/LSM6DS3TRC on TICI/tizi. |
| `magnetometer` | 25 Hz | `magneticUncalibrated` with `v` and status | LIS2MDL on KA2; MMC5603NJ only on tizi. |
| `temperatureSensor` | 2 Hz | scalar `temperature` | ICM42670 on KA2; LSM6DS3/LSM6DS3TRC on TICI/tizi. |

Frequencies are declared in `cereal/services.py:25–29`; platform mapping is in `system/sensord/sensord.py:99–119`. No new interface items are proposed.

## Field-presence and timestamp contract

An event-construction helper must preserve the existing per-driver choices below. In particular, `sensor` and `type` are not uniformly assigned, and some drivers use a timestamp source that does not honor the optional `ts` argument. A helper that fills default values or substitutes one clock for another is a contract change and must not be used.

| Driver | Timestamp | Version / sensor / type | Union and status | Preserve |
| --- | --- | --- | --- | --- |
| ICM42670 accel | supplied `ts`, else `time.monotonic_ns()` | v1, sensor 1, type 1 | `acceleration`; status 1 | rotated/scaled axes and source `icm42670`. |
| LSM6DS3 accel | IRQ-supplied `ts` required | v1, sensor 1, type 1 | `acceleration`; status 1 | `[y, -x, z]`, chip-ID-dependent source. |
| ICM42670 gyro | supplied `ts`, else `time.monotonic_ns()` | v1, sensor 5, type 16 | `gyroUncalibrated`; status 1 | bias-adjusted values, rotated X/Z components, source `icm42670`. |
| LSM6DS3 gyro | IRQ-supplied `ts` required | v2, sensor 5, type 16 | `gyroUncalibrated`; status 1 | axis order and chip-ID-dependent source. |
| LIS2MDL magnetometer | supplied `ts`, else `time.monotonic_ns()` | v1, sensor 3, type 14 | `magneticUncalibrated`; status 1 | axis mapping and source `lis2mdl`. |
| MMC5603NJ magnetometer | always `time.monotonic_ns()`; `ts` is ignored | v1, sensor 3, type 14 | `magneticUncalibrated`; status reflects sentinel validation | six values from SET then RESET cycles and source `mmc5603nj`. |
| ICM42670 temperature | supplied `ts`, else `time.monotonic_ns()` | v1, type 4; `sensor` left unset | scalar `temperature` | source `icm42670`. |
| LSM6DS3 temperature | `int(time.monotonic() * 1e9)`; `ts` is ignored | v1; `sensor` and `type` left unset | scalar `temperature` | source chosen from chip ID. |

Sources are `system/sensord/sensors/icm42670_accel.py:45–65`, `icm42670_gyro.py:92–113`, `icm42670_temp.py:24–34`, `lsm6ds3_accel.py:64–87`, `lsm6ds3_gyro.py:59–83`, `lsm6ds3_temp.py:24–30`, `lis2mdl_magn.py:32–48`, and `mmc5603nj_magn.py:47–65`.

## Error and validity behavior

- Polling sensors remain silent until `Sensor.is_data_valid()` passes its 0.5-second window (`i2c_sensor.py:57–62`). Invalid reads are not published; the refactor only ensures that each invalid iteration is paced.
- The interrupt path suppresses `Sensor.DataNotReady`, logs other processing errors, and keeps its realtime/monotonic timestamp conversion (`sensord.py:43–78`).
- Polling exceptions continue to be logged as `Error in {service} polling loop` (`sensord.py:85–94`).
- Initialization/reset/shutdown failure logging remains unchanged (`sensord.py:121–143,152–162`).

## Typed design-to-build evidence

```yaml
change: none
items: []
artifacts:
  - skillset-saves/runs/sensord-refactor-20261029/design/reports/report_interfaces.md
```

The `items` list is empty because no external or internal service contract is changing; the report records the existing inventory and exact compatibility boundary. Commander should attach this artifact to the typed `interface_set` evidence.

## UI applicability

```yaml
applicable: false
reason: no user-facing surface - design system not engaged
scope: design-to-build
decided_by: architect
```

This is a backend sensor daemon and its consumers are existing cereal subscribers. No visual design-system artifact is due.
