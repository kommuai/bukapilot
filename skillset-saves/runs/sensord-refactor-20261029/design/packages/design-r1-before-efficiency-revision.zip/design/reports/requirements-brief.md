# Requirements Brief — `system/sensord` efficiency refactor

**Revision:** 3  
**Sources mined:** Admiral intake, `system/sensord`, `cereal/services.py`, `system/sensord/tests/test_sensord.py`, and a read-only `/dev/i2c-*` enumeration during resumed research  
**Prepared for:** `design/architect`

## Actors and jobs

| Actor | Job to be done | Success looks like | Frequency / volume |
| --- | --- | --- | --- |
| Downstream sensor-service subscribers | Consume the vehicle’s accelerometer, gyroscope, temperature, and applicable magnetometer events. | Existing service names, cadence, timestamps, values, metadata, and warmup validity remain unchanged. | Continuous; 104 Hz accel/gyro, 25 Hz magnetometer, 2 Hz temperature (`cereal/services.py:25–29`). |
| `sensord` / vehicle operator | Initialize the platform’s selected sensors, publish valid readings, and shut down the hardware cleanly. | Existing KA2 versus TICI/tizi selection, IRQ/polling behavior, logged failures, and shutdown sequence remain intact (`system/sensord/sensord.py:99–162`). | Startup, continuous sampling, and process shutdown. |

## Requirements

| # | Requirement | Source | Confidence | Affects | Open assumption |
| --- | --- | --- | --- | --- | --- |
| R-1 | The selected sensor set and polling/interrupt ownership must remain the same on KA2 and TICI/tizi. | `system/sensord/sensord.py:99–119`; Admiral intake `intake-brief.md` | observed | Architecture boundary and sensor lifecycle | None identified. |
| R-2 | Published events must retain their existing service names and configured frequencies. | `system/sensord/sensord.py:81–94`; `cereal/services.py:25–29`; `system/sensord/tests/test_sensord.py:115–151` | observed | Polling and publication interfaces | Hardware cadence remains to be verified on target after implementation. |
| R-3 | Successful sensor events must retain their current field choice, values, timestamp source, version, sensor/type identifiers, source, and status, including fields currently left unset. | Driver implementations in `system/sensord/sensors/` (for example `icm42670_accel.py:45–65`, `lsm6ds3_accel.py:64–87`, `mmc5603nj_magn.py:47–66`, and `icm42670_temp.py:24–34`) | observed | Interface contract and event-construction refactor | No interface change is requested. |
| R-4 | Polling sensors must continue to suppress publication until `Sensor.is_data_valid()` passes its current 0.5-second startup window. | `system/sensord/sensors/i2c_sensor.py:57–62`; `system/sensord/sensord.py:81–94` | observed | Polling behavior and startup acceptance | None identified. |
| R-5 | Invalid polling iterations must not bypass the configured service-rate pacing. | `system/sensord/sensord.py:81–94` shows invalid data `continue`s before `rk.keep_time()`; the intake identifies this as the bounded CPU-efficiency opportunity. | inferred | Polling-loop design and offline acceptance | The actual bus-read and CPU effect remains unmeasured: the present I²C device nodes' identity and functional access, a confirmed KA2/TICI rig, and a before/after baseline remain unknown. |
| R-6 | For a fixed ICM42670 gyro sample sequence, calibration means, standard deviations, stationarity result, and selected bias must remain identical. | `system/sensord/sensors/icm42670_gyro.py:32–35, 70–90` | observed | Calibration buffer implementation and equivalence tests | Compact storage must preserve the exact integer samples and their order. |
| R-7 | Initialization errors, `DataNotReady` handling, other per-sensor error logging, IRQ timestamp handling, and sensor shutdown must retain existing behavior. | `system/sensord/sensord.py:47–78, 121–162`; driver shutdown methods in `system/sensord/sensors/` | observed | Error, interrupt, and lifecycle paths | Target hardware is required to verify actual IRQ and shutdown behavior. |
| R-8 | Refactoring should reduce repeated fixed per-sample work, calibration storage, and duplicate event-construction code without changing requirements R-1 through R-7. | User request recorded in `intake/report_grilling.md`; candidate scope in `intake/intake-brief.md` | reported | Architecture and implementation scope | No quantitative savings target was supplied; see Q-1. |

## Constraints

| # | Constraint | Kind | Source | Confidence | Affects |
| --- | --- | --- | --- | --- | --- |
| C-1 | Do not change cereal schemas, service names, sensor identities, register configuration, sensor topology, bus ownership, thread topology, or externally published behavior. | technical | `intake/intake-brief.md`; current configuration in `system/sensord/sensord.py:99–119` | reported / observed | Architecture and interfaces |
| C-2 | Preserve calibration constants and the existing `statistics.fmean` / `statistics.pstdev` calculation; do not substitute an approximate online algorithm. | `intake/report_grilling.md`; `system/sensord/sensors/icm42670_gyro.py:32–35, 70–90` | reported / observed | Calibration design | Any alternative requires new user approval and equivalence evidence. |
| C-3 | Preserve unrelated existing checkout edits. | `git status --short` at intake; Admiral handoff | observed | Build scope | Changes remain confined to the sensord refactor and its focused tests. |
| C-4 | `/dev/i2c-0`, `/dev/i2c-1`, `/dev/i2c-3`, `/dev/i2c-6`, `/dev/i2c-9`, and `/dev/i2c-10` character devices are present; their hardware identity and functional sensor access are unverified. | Read-only `/dev/i2c-*` enumeration during resumed research (2026-10-29) | observed | Hardware integration and comparative performance evidence | A target owner must identify the attached board/sensors and confirm a safe test target before device checks. |
| C-5 | Current harness runtime is Python 3.12.3, below its 3.13 minimum; the run’s readiness record also reports missing Codex hooks. | Admiral handoff and local readiness diagnostic | observed | Gate/check execution and environment readiness | Admiral owns environment readiness; do not alter environment in this design scope. |

## Non-functional targets

| Target | Number | Source | Confidence | Why this number |
| --- | --- | --- | --- | --- |
| CPU use and resident-memory change | Not specified; no measured target | User request and `intake/intake-brief.md` | reported | A target-device baseline and an agreed budget are needed before a quantified improvement can be claimed. |

## Non-goals

- No sensor, register, bus, thread-topology, service-schema, or sample-rate changes; reopen only for an approved hardware or interface change.
- No thread or bus consolidation; reopen only if later target measurements identify it as a necessary, separately validated change.
- No approximate calibration algorithm; reopen only with an approved numerical-equivalence plan and evidence.
- No target-speedup claim or hardware-integration signoff in this environment; reopen when a KA2/TICI rig and an agreed CPU/RSS measurement window are available.
- No UI, runtime, framework, or dependency change in this scope.

## Prior art and comparable flows

| Source | What it shows | Why it transfers (or does not) |
| --- | --- | --- |
| `system/sensord/tests/test_sensord.py:78–224` | Existing hardware integration checks sensor presence, approximate accel/gyro timing, service frequency, timestamp relationships, values, and IRQ cessation after stop. | Directly applicable as the device-level regression suite; it is marked TICI and starts the managed hardware process, so it is not an offline test and does not cover KA2 here. |
| `system/sensord/sensord.py:81–94` | Polling creates a `Ratekeeper` at the service frequency, but the invalid-data branch continues before keeping time. | Direct repository evidence for the bounded polling-efficiency design question; it does not quantify CPU savings. |

## Conflicts preserved

| Conflict | Position A (source, confidence) | Position B (source, confidence) | Who decides |
| --- | --- | --- | --- |
| None found in the scoped intake and current source. | — | — | — |

## Open questions

| Question | Blocks | Owner | Latest safe decision point |
| --- | --- | --- | --- |
| What CPU reduction and RSS ceiling or improvement threshold should count as success? | A quantified performance claim, not the behavior-preserving internal refactor. | User/target owner with `build/build-management` | Before any target performance claim is accepted. |
| Which board and sensors, if any, are attached to the currently visible `/dev/i2c-*` nodes, and when can a confirmed KA2/TICI rig be used for integration checks and comparative CPU/RSS measurement? | Hardware validation and comparative performance evidence. | User/target owner | Before device-level validation or any target-performance claim; this run stops before rollout. |
| Can the local harness runtime and Codex hook setup be brought to their required readiness independently of this code change? | None of the sensord design decisions; may limit gate tooling. | Admiral/operator | Before any gate check that requires the unavailable capability. |

## Limitations

- `/dev/i2c-*` character devices are present, but no board or sensor identity, functional access, confirmed KA2/TICI rig, or agreed performance baseline is established. No hardware integration or target CPU/RSS comparison was run. R-5’s efficiency effect is a design inference from the existing control flow, not a measured result.
- The existing integration test is hardware-dependent and TICI-marked; KA2 behavior needs a KA2-specific device run to validate.
- The local harness reported Python 3.12.3 (<3.13) and missing Codex hooks. This is an environment limitation, not evidence of a product defect.
