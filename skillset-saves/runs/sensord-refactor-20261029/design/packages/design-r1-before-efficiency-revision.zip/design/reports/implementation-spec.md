# Implementation Spec — system/sensord efficiency refactor

**Revision:** 1  
**Design package revision:** sensord-refactor-20261029-design-r1  
**Detected stack:** No registry slug was established: the repository-wide detector stopped at its byte limit. The inspected root pyproject.toml declares Python >=3.11,<3.13; Python 3.12.3 is product-compatible but below the harness minimum of 3.13. This design adds no runtime, framework, or dependency.

## Slice order

| # | Slice ID | Depends on | Plan milestone | Acceptance owner |
| --- | --- | --- | --- | --- |
| 1 | slice.sensord.poll-ratekeeper | None; root of the implementation chain | M1 | build/build-management |
| 2 | slice.sensord.fixed-calculations | No functional dependency; schedule after M1 to keep the control-flow and numeric changes reviewable as separate milestones | M2 | build/build-management |
| 3 | slice.sensord.gyro-buffer | No functional dependency; schedule within M2 after M1 and keep the gyro module wholly owned by this slice | M2 | build/build-management |
| 4 | slice.sensord.event-construction | Slices 2 and 3, plus the approved interface contract; M3 follows M2 to isolate the field-parity change | M3 | build/build-management |

AC-4 is the whole-change review criterion for all four slices, not a fifth implementation slice.

## Slices

### slice.sensord.poll-ratekeeper

**Modules owned:** system/sensord/sensord.py; new system/sensord/tests/test_polling_pacing.py. No sibling slice may change these paths.

**Depends on:** None.

**Data / migration changes:** None. There is no persisted state or schema.

**Contract tests:** No request/response API is in scope. Preserve the existing polling service names, publication payload, Ratekeeper frequency, warmup silence, exception logging, and shutdown behavior.

**Proof plan:** First add an offline regression test that fails on the current invalid-data early continue: substitute a sensor whose validity check remains false, a recording Ratekeeper, and a recording publisher. The test must prove one keep_time call per polling iteration and zero publications while the sensor is invalid. Then make the smallest control-flow change that leaves each iteration on the existing keep_time path; retain the current read, validity, publish, and exception behavior. Run only pytest -q system/sensord/tests/test_polling_pacing.py for this slice.

**Rollback:** Revert this slice's sensord.py change and its new test file. No other slice-owned path is changed.

**Acceptance evidence:** AC-1: the focused offline test demonstrates that invalid iterations are paced and no warmup event is published; build/build-management accepts it.

### slice.sensord.fixed-calculations

**Modules owned:** system/sensord/sensors/icm42670_accel.py; system/sensord/sensors/lsm6ds3_accel.py; system/sensord/sensors/lsm6ds3_gyro.py; system/sensord/sensors/mmc5603nj_magn.py; new system/sensord/tests/test_fixed_calculations.py. ICM42670 gyro calculations stay with slice.sensord.gyro-buffer, and temperature/event-construction modules stay with slice.sensord.event-construction.

**Depends on:** No functional dependency. The plan places this work in M2 after the separately reviewable M1 polling change.

**Data / migration changes:** None.

**Contract tests:** Preserve the existing acceleration, gyroscope, and magnetometer values, axis ordering, source, and published message fields. No service, schema, sensor, or register change is allowed.

**Proof plan:** Add offline tests with fixed raw register-byte fixtures and mocked reads. Record the pre-change expected numeric outputs, then move only fixed scales and trigonometric values out of repeated sample work. Keep expression order unchanged where floating-point rounding can differ. Verify exact outputs for each covered driver; run pytest -q system/sensord/tests/test_fixed_calculations.py.

**Rollback:** Revert only the four driver changes and this test file. Do not revert files owned by another slice.

**Acceptance evidence:** AC-2, numeric equivalence portion: fixed transforms and scales produce the same values for the same raw samples; build/build-management accepts it.

### slice.sensord.gyro-buffer

**Modules owned:** system/sensord/sensors/icm42670_gyro.py; new system/sensord/tests/test_gyro_buffer.py. No other slice may edit the ICM42670 gyro module.

**Depends on:** No functional dependency; schedule within M2 after M1 as the plan does. This slice may also hoist fixed conversion or rotation values in this module because its whole-file ownership is exclusive.

**Data / migration changes:** None. The calibration buffer is process-local and recreated during initialization.

**Contract tests:** Preserve the 300 sample count, 5 ms interval, signed raw integer values, sample order, statistics.fmean and population statistics.pstdev, mean and standard-deviation thresholds, stationary classification, and selected bias.

**Proof plan:** Add a deterministic offline test with a fixed ordered set of signed 16-bit XYZ samples. Prove the compact representation has the expected signed width and retains all sample values and order, including the representable endpoints. Compare each axis's means, population standard deviations, stationarity result, and selected bias against the current implementation. The implementation may use a compact signed-short array only after confirming its item width is two bytes; otherwise it must use an equally compact representation with explicit range checks. Keep fmean and pstdev and feed them the same ordered integer values. Run pytest -q system/sensord/tests/test_gyro_buffer.py.

**Rollback:** Revert only the ICM42670 gyro change and its test file. No persisted data needs conversion.

**Acceptance evidence:** AC-2, calibration portion: the fixed sequence produces identical statistics, classification, and bias; build/build-management accepts it.

### slice.sensord.event-construction

**Modules owned:** new system/sensord/sensors/sensor_event.py; system/sensord/sensors/icm42670_temp.py; system/sensord/sensors/lsm6ds3_temp.py; system/sensord/sensors/lis2mdl_magn.py; new system/sensord/tests/test_event_construction.py. Drivers owned by slices 2 and 3 remain local and are not imported into this helper.

**Depends on:** slice.sensord.fixed-calculations and slice.sensord.gyro-buffer, as M3 follows M2 in the approved plan.

**Data / migration changes:** None.

**Contract tests:** Keep the interface report's change:none contract. The helper must accept timestamp, version, source, optional sensor and type, union name, payload, and status explicitly. Omitted sensor/type fields must remain unset. Retain each selected driver's timestamp behavior, including whether it accepts or ignores the optional timestamp.

**Proof plan:** First add offline expected-field fixtures from the current constructors. Use mocked reads only; do not open I2C devices. Compare serialized event values and field presence, covering version, source, timestamp, optional sensor/type, union choice, payload order, status, and unset defaults. Integrate the helper only for drivers whose exact behavior passes these checks; keep any driver-local constructor whose defaults or timestamp behavior do not fit. Run pytest -q system/sensord/tests/test_event_construction.py.

**Rollback:** Remove the shared helper and restore local constructors for this slice's drivers, plus revert its new test file. This rollback does not affect the numeric or polling slices.

**Acceptance evidence:** AC-3: tests show exact event parity for every driver moved to the helper; any driver without proof remains local. build/build-management accepts it.

## Operational constraints

| Constraint | Slices affected | Owner | Removal criterion |
| --- | --- | --- | --- |
| No schema, service-name, sensor, register, bus, thread, or publication-cadence changes | All | build/build-management | None; these remain fixed for this design |
| Tests are offline and use mocked reads/events; do not access the visible /dev/i2c-* nodes or run the hardware integration test | All | build/build-management | Separate target-owner decision identifies a safe KA2/TICI rig and confirms access |
| Make no measured CPU/RSS claim; node identity, functional access, confirmed rig, and before/after baseline remain unknown | All | User/target owner with build/build-management | Target, workload, measurement window, and success threshold are agreed |
| No new runtime, framework, dependency, migration, or operational cutover | All | build/build-management | A separate approved design revision is required before widening scope |
| Harness Python minimum is 3.13, while current Python is 3.12.3; Codex hooks are missing and repository stack detection is incomplete | Gate and validation steps | Admiral/operator | Use a supported runtime and registered hooks before claiming checks that depend on them; do not change environment as part of this code scope |

## Whole-change acceptance and handoff

- AC-1 through AC-3 map to the slice evidence above.
- AC-4: report the scoped file list and non-test implementation LOC delta with git diff --numstat -- system/sensord; run git diff --check; confirm no unapproved paths changed. Acceptor: review/code-chief.
- The hardware integration test in system/sensord/tests/test_sensord.py is not an offline target for this run. Device-level checks and CPU/RSS measurement remain deferred to a target owner.
- A safe implementation sequence is M1, the two M2 slices, then M3; M4 is the build/review verification milestone. No slice requires a migration, feature flag, new dependency, deployment change, or hardware rollout.

