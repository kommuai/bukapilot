# Taste snapshot revalidation

**Run:** `sensord-refactor-20261029`  
**Phase:** design  
**Submission:** `sensord-refactor-20261029-design-r3` (revision 56)  
**Owner:** taste  
**Boundary:** design-to-build  
**Preamble tier:** 2 — delegated multi-step design evidence revalidation.  
**Decision:** reuse the existing immutable snapshot; no profile drift found.

## Snapshot

- Artifact: `artifacts/taste_snapshot.json`
- File SHA-256: `4b29408d876a909bc0a1eec35f78abf384a72276b6f6972da35e2f99a6244a8f`
- Canonical digest: `sha256:1beb862ffc2faa7ade5f7b2308f2803bc9cea1981dbf2144ce044fa8ebd9132b`
- Source revisions in the snapshot and current stores: global `0`, project `0`

The snapshot was retained byte-for-byte. It records `applicable: false` with the sanctioned reason `no saved Taste profile available`, scope `both`, empty resolved and shadowed entries, and no unresolved conflicts.

## Read-only revalidation

I used the sanctioned reader at `/data/kommu/.codex/skills/taste/taste_prefs.py` from the `/data/openpilot` project root:

- `status --scope global`: store absent, revision `0`, status digest `sha256:9dd4489943229ae9f8be2fb0423d4de64109eb8ff3a1f794fafead91721413a1`
- `status --scope project`: store absent, revision `0`, status digest `sha256:2fe4359b090c82a841b7b0bdb1400e4ec135fb5b29c20018b68eeb91caaed651`
- `list --scope global` and `list --scope project`: both entry maps empty
- `effective --scope both`: effective entries empty

All reads succeeded. The current store state matches the snapshot's source revisions and resolved entries, so there is no taste-profile drift. The status digests for missing stores differ from the snapshot's saved `source_digests` (`global` `sha256:6a0b726a0b77a18aaa6abb8d2d74f8f85edf9bd7c6ec8986793a8f46b60bbaa3`; `project` `sha256:cb917ebdfa8544d43d15abe2217617702869c66a254a25a76c909f80fc1e5b0a`) because the reader constructs a synthetic blank record with a generated timestamp when a store is absent. The writer implementation's `blank()` function includes `generated_at`; absence, revision, and entries are therefore the stable comparison for these stores. This is consistent with the prior snapshot report.

No preference store or source artifact was changed. No replacement snapshot was needed.
