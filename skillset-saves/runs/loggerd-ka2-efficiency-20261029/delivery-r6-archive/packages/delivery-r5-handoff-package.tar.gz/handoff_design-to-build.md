---
submission_id: loggerd-ka2-efficiency-20261029-design-r5
revision: r5
boundary: design-to-build
verdict: APPROVED
phase_verdict: APPROVED
cross_stage_verdict: PENDING
---

# Admiral handoff: design to build

The r5 design phase is approved for the design-to-build boundary. The cross-stage review is pending; build/build-management may begin only after a fresh Admiral cross-stage APPROVED verdict.

## Approved package and lineage

- Design manifest: [r5 manifest](../../design/manifest.json) — SHA-256 fbbf6db9fe551149cc931fd85493f7df7b8fcb516d2fe45826a0b4cefd7f7f5d.
- Consolidated design package: [r5 design package](../../design/reports/design-package.md) — SHA-256 267a4a4eeb37db1015366c7313e1f285cb178216d194ec4cf49139024538bc6a.
- Phase verdict: [design-to-build r5 verdict](../../design/verdict_design-to-build.json) — APPROVED, fingerprint 1142647054439e80ba7411da93983f41fb1cd5d5784ad41b3549a9a67edcdb9d, verdict id 2d59b79e0d27c97b8492d0d344687282e5de9885c190c66381a8ef872e5bea65.
- Interface contracts: [report_interfaces.md](../../design/reports/report_interfaces.md) — SHA-256 c8306fb91ada0009f7ce56c430a574c8183a2f2bcbc7728516e04bbe166ccbd7.
- Acceptance and delivery plan: [delivery-plan.md](../../design/reports/delivery-plan.md) — SHA-256 a1f72d7fcfe285ed92867be472245a6a44d40981e060029c6097c47eb01fa1ae.
- Implementation specification: [implementation-spec.md](../../design/reports/implementation-spec.md) — SHA-256 25399154e743720e0229f9e090c0458b470f2613d29cb39bf01b4f63b24d1442.

The r5 package closes the three r4 design findings. It preserves the existing manager signal and wait order, separates pre-code feasibility from the post-implementation drain proof, and defines an input-derived frame-ID/segment oracle that does not rely on the known-lossy capture.

The prior Admiral cross-stage r3 review returned ESCALATE for stale r2 handoff metadata and for running the package checker with the source checkout as root while saves physically reside under /data/media. This r5 handoff names only revision r5. The package prechecks now run from the canonical media save root; a new cross-stage verdict is still required.

## Scope and next phase

The approved sequence is:

1. **S0 feasibility:** establish exact built/launched binary and loaded MPP/RGA identities, EOS/IDR capability, VisionIPC ring retention, queue and packet bounds, memory headroom, and the static manager order. Any unknown or infeasible prerequisite stops before implementation.
2. **S1 copy-path correctness:** after S0, implement the approved lifecycle correction and prove whole-process frame conservation, output behavior, bounded queues, and the actual concurrent manager shutdown sequence. The shared drain deadline is 4500 ms; any failed hard gate stops later work.
3. **S2 corrected-copy reference:** only after S1 passes, repeat captures and establish the exact event, audio, decoded-media, and segment reference.
4. **S3/S4 candidate and efficiency evidence:** profile and qualify the existing opt-in candidate, then run paired measurements only after correctness and reference gates pass. No speedup or CPU/memory reduction is claimed now.
5. **S5 LOC review:** one behavior-preserving pass after runtime behavior is settled; report source and test LOC separately.

## Runtime authorization and current evidence

D-6 authorizes bounded synthetic correctness work on the production KA2 only while it is idle, with a fresh preflight, isolated temporary roots, and the existing time, output, memory, and thermal limits. It does not authorize live camera/sensor input, I2C, or on-road capture. Performance comparison remains separately gated by the corrected-copy and candidate correctness evidence.

Three earlier synthetic runs each emitted every frame ID submitted in that run exactly once, but their submitted counts and segment maps varied. See [the repeatability report](../../build/report_copy_runtime_repeatability.md). Those runs do not establish the clean S2 media reference, concurrent manager-shutdown behavior, or an efficiency gain. No performance samples have been collected.

The current working-tree implementation is not approved by this design handoff. Build-management must begin with S0 after cross-stage approval and must not infer runtime behavior from the existing candidate or the synthetic frame-ID runs.
