---
submission_id: loggerd-ka2-efficiency-20261029-design-r5
revision: r5
boundary: design-to-build
phase_verdict: APPROVED
cross_stage_verdict: PENDING
---

# Delivery package: loggerd and encoderd KA2 efficiency

## Current status

The r5 design-to-build phase verdict is APPROVED. Admiral's cross-stage review is pending, so the build phase has not started. The prior cross-stage r3 verdict was ESCALATE: the handoff named r2 while the phase package named r3, and the checker was run with /data/openpilot as its containment root even though the canonical save tree is under /data/media. The r5 handoff and design package now identify one submission; design prechecks pass from the canonical media save root. A fresh cross-stage verdict is still required before build work.

- [r5 design manifest](../../design/manifest.json) — SHA-256 fbbf6db9fe551149cc931fd85493f7df7b8fcb516d2fe45826a0b4cefd7f7f5d
- [r5 design package](../../design/reports/design-package.md) — SHA-256 267a4a4eeb37db1015366c7313e1f285cb178216d194ec4cf49139024538bc6a
- [r5 phase verdict](../../design/verdict_design-to-build.json) — APPROVED; fingerprint 1142647054439e80ba7411da93983f41fb1cd5d5784ad41b3549a9a67edcdb9d; verdict id 2d59b79e0d27c97b8492d0d344687282e5de9885c190c66381a8ef872e5bea65
- [r5 delivery plan](../../design/reports/delivery-plan.md)
- [r5 implementation specification](../../design/reports/implementation-spec.md)
- [r5 design self-check](../../design/evidence/commander-design-selfcheck-final.log)
- [r5 package-shape check](../../design/evidence/commander-design-shapecheck-canonical.log)

## Approved next-phase contract

The request is to reduce KA2 loggerd/encoderd CPU and memory without changing recording behavior, then report any source/test line-count reduction separately. The design orders this as correctness first, measurement second:

- **S0:** pin exact executable and loaded-library identity; prove loaded-image MPP/EOS/IDR capability, VisionIPC retention, queue and encoded-packet bounds, memory feasibility, and static manager stop order. Unknown or infeasible constraints are hard stops before product changes.
- **S1:** correct the copy-path lifecycle and prove every input ID appears exactly once through startup, rotation, recovery, and concurrent shutdown. The manager source/order is unchanged; both processes must complete under the shared 4500 ms drain deadline.
- **S2:** establish a clean repeated-copy reference for exact logs, segments, audio, and decoded camera output.
- **S3/S4:** qualify a bounded profile-supported candidate and run randomized paired CPU/RSS/available DMA-memory and latency measurements only after correctness passes. Keep copy as the default unless measured gains satisfy the agreed confidence and no-regression rules.
- **S5:** perform one behavior-preserving LOC pass after runtime behavior is settled.

The known-lossy captures (138/144 and 137/145 emitted frame IDs) cannot qualify as baseline evidence. The later three-run synthetic check conserved each run's submitted IDs but varied in run length and segment mapping; it does not establish the S2 reference. Existing ENCODER_ZERO_COPY behavior remains opt-in until its exact-build correctness and paired efficiency gates pass.

## Runtime constraints and evidence

D-6 authorizes bounded synthetic correctness checks on the production KA2 only while it is idle, following a fresh target/process/MPP preflight with isolated temporary outputs and the established time, storage, memory, and thermal ceilings. This authorization does not include live cameras or sensors, I2C, or on-road recording. Performance measurement requires the additional design acceptance gates and a separate fresh preflight.

No CPU, RSS, DMA-memory, or latency improvement has been measured. Existing source changes are not approved for the next phase by this package; after cross-stage approval, build-management starts with S0 and stops on any unknown feasibility result.
