---
revision: r1
---

# Internal endpoint contracts — sidecamerad MVP

**Architecture basis:** revision 11 (`report_architecture.md`, `report_interfaces.md`). This is an additive contract supplement; it does not add an HTTP, remote RPC, or network listener.

## Endpoint inventory

| Method | Path / topic | Purpose | Consumer | Owner | Auth | State change | Contract tests |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `VisionIPC SUB` | `sidecamerad`, stream 7 / ZMQ port 9007 | Read front-left NV12 frames | Local VisionIPC client | `sidecamerad` | No per-client auth; host-local IPC permissions | No | Required |
| `VisionIPC SUB` | `sidecamerad`, stream 8 / ZMQ port 9008 | Read front-right NV12 frames | Local VisionIPC client | `sidecamerad` | No per-client auth; host-local IPC permissions | No | Required |
| `VisionIPC SUB` | `sidecamerad`, stream 9 / ZMQ port 9009 | Read back-left NV12 frames | Local VisionIPC client | `sidecamerad` | No per-client auth; host-local IPC permissions | No | Required |
| `VisionIPC SUB` | `sidecamerad`, stream 10 / ZMQ port 9010 | Read back-right NV12 frames | Local VisionIPC client | `sidecamerad` | No per-client auth; host-local IPC permissions | No | Required |
| `cereal SUB` | `frontLeftCameraState`, `frontRightCameraState`, `backLeftCameraState`, `backRightCameraState` | Receive per-camera frame metadata at 20 Hz | Local cereal subscriber | `sidecamerad` | Existing host-local cereal transport; no per-topic auth | No | Required |
| `ENV CONFIG` | `SIDECAMERAD`; `SIDECAM_FRONT_LEFT`, `SIDECAM_FRONT_RIGHT`, `SIDECAM_BACK_LEFT`, `SIDECAM_BACK_RIGHT` | Opt in and assign paths to positions | Process manager / `sidecamerad` | Operator and `sidecamerad` | Local process environment | Selects configured workers only | Required |

For the non-ZMQ VisionIPC backend, the server control socket is keyed by `get_ipc_path("sidecamerad")` and the data endpoint uses the existing `visionipc_sidecamerad_<stream-id>` name convention. Under ZMQ, `get_endpoint_name` uses port `9000 + stream ID` and loopback transport. This requires adding `sidecamerad` to the existing endpoint-name allowlist. Existing IDs 0–6 and their endpoints remain unchanged.

## Common pub-sub contract

**Owner and consumers:** The sidecar owns the streams and metadata publications. A local client connects by server name plus the assigned stream ID; a cereal client subscribes to the matching state topic. The topic and VisionIPC stream are separately consumed and keyed by the same camera position and `frameId`; there is no cross-channel atomic delivery guarantee.

**Auth and authorization:** There is no application identity, role, tenant, or per-topic authorization model in this local embedded IPC surface. Access is limited to processes able to use the host-local VisionIPC/cereal transports and their existing OS-level permissions. The server binds only to the established local transport, with no routable listener. A stronger local consumer boundary is not specified by this MVP.

**Request and response shape:** These are one-way subscriptions, not request/response RPC. VisionIPC yields a complete 1280×720 NV12 frame (1,382,400 bytes); cereal yields the existing `FrameData` type with `frameId`, `timestampEof`, and nominal `timestampSof`. `FrameData.image` remains unset so pixels are not duplicated in cereal; pixels are read from the matching VisionIPC stream. The four service declarations use 20 Hz and `should_log=False`, so side-camera images do not enter drive logs through cereal. There are no path/query parameters, custom headers, request bodies, HTTP status codes, or JSON error envelope.

**Empty and error behavior:** A missing path has no worker, frame stream, or state publication for that position. IF-2's “invalid/unavailable paths” retry case means a syntactically valid V4L2 path that cannot be opened as an available device; that worker closes/reaps and retries on the backoff schedule. A malformed path shape is rejected before FFmpeg launch and is not retried. A decoder failure also closes/reaps the child and retries that position. During a failure or backoff, that position emits no frame and no state; configured siblings and native `camerad` continue. A client observes an unavailable local stream or no new messages and may reconnect using the existing client behavior. The sidecar logs per-position startup, decoder exit/short-frame, and retry events; it does not publish a new error topic. Decoder retry delay is 1, 2, 4, 8, 16, then 30 seconds maximum, with child close/reap before retry.

**Behavior and resource contract:** The manager starts a distinct sidecar only when `SIDECAMERAD=1`; native `camerad` keeps its existing policy. Each configured path is validated as one explicit V4L2 device path and is passed as data to the fixed existing FFmpeg executable through direct argv, with no shell or environment-selected executable/options. Each worker captures 1280×720 MJPEG at 20 fps, decodes to NV12 with one FFmpeg thread, accepts only complete frames of exactly 1,382,400 bytes, and uses one reusable scratch frame plus three VisionIPC buffers. The sidecar has no BGR conversion, app frame queue, persistence, or image sink. SOF is nominally 50,000,000 ns before host-monotonic EOF; this is not a hardware exposure timestamp or cross-camera sync promise. The cadence target is not a guarantee: four-camera performance remains unmeasured pending the AC-4 soak.

**Side effects, retry, and consistency:** Subscribing is read-only. Device configuration creates only the selected workers. Failed workers restart independently with the bounded schedule above; there is no replay store or transaction spanning the cereal topic and VisionIPC. `frameId` increases per position across worker retries while the sidecar remains running; it is not persisted across a whole-process restart.

**Pagination, filtering, sorting, caching, and quotas:** Not applicable to fixed-rate local frame streams. The service target is 20 Hz per configured camera; frames may be absent during capture failure. No replay, cache, or server-side filtering is introduced.

**Security and privacy:** Camera pixels and local MJPEG input are sensitive/untrusted. Preserve the current host-local binding and permissions; do not add remote access. Do not log frame bytes or image payloads. Keep FFmpeg diagnostics bounded, avoid unrelated inherited descriptors, and retain the unprivileged identity. The design cannot promise a hard FFmpeg memory/CPU cap on the target until build-time platform support is confirmed; if unsupported, report the residual decoder-resource exposure for owner/security review.

**Versioning and compatibility:** Version by additive schema and enum extension. Add `FrameData` Event arms at ordinals 150–153, after `audioFeedback @149`, and add the four 20 Hz service names. Append VisionIPC IDs 7–10 in both C++ and Cython enum definitions. Do not renumber or change existing services, ordinals, IDs, or native `camerad`; no deprecation is planned for this MVP.

**Observability:** Record per-position frame count/cadence, frame gaps, child restarts, and retry delay for smoke/soak analysis; capture CPU utilization during AC-4. Logs contain lifecycle and bounded decoder diagnostics only, with no frame bytes. Distributed traces and correlation IDs are not applicable to this local single-process pub-sub surface.

## Focused contract tests

- Positive: each configured position publishes only its assigned stream/topic; verify IDs 7–10, the 9000+ID ZMQ convention, local sidecamerad control path, 20 Hz service declarations, complete NV12 dimensions/size, increasing frame IDs, and the specified host timestamps.
- Configuration and error: flag unset/0 starts no sidecar; flag 1 accepts a partial path set; missing/invalid paths publish nothing for that position; a truncated/failed FFmpeg child is closed and reaped, retries on the bounded schedule, and does not stop sibling or native `camerad` publication.
- Security and compatibility: assert the FFmpeg child receives a fixed argv with the single validated device path and no shell; verify no listener binds to a routable interface, no frame bytes are logged, ordinals/stream IDs 0–6 and existing services remain unchanged, and the sidecar does not publish during backoff.

## UI handoff

Not applicable: the MVP has no screen or frontend consumer. Local cereal and VisionIPC contracts above are the complete consumer interface for this slice.
