---
revision: r1
run_id: sidecamerad-mvp-20261113
---

# Design package — opt-in sidecamerad MVP

**Run:** `sidecamerad-mvp-20261113` · **Revision:** `r1`  
**Boundary:** `design-to-build` · **Owner:** `commander`

## Scope and outcome

Deliver one additive `sidecamerad` process alongside native `camerad`. Only `SIDECAMERAD=1` starts the sidecar. Four explicitly configured V4L2 paths are optional so a partial set can be used for the current one-camera smoke test. For each configured position, publish its matching 20 Hz cereal state and a distinct VisionIPC stream: front-left 7, front-right 8, back-left 9, back-right 10. Keep existing stream IDs 0–6 and cereal ordinals through 149 unchanged.

Use the already available FFmpeg executable for 1280×720 MJPEG-to-NV12 capture. The architecture uses one FFmpeg thread, one worker and reusable scratch frame per configured camera, three VisionIPC frame buffers per stream, exact-size reads, and no BGR conversion or application frame queue. Four-camera image payload is calculated at 22,118,400 bytes (21.09 MiB); this excludes FFmpeg internal memory, kernel/V4L2 buffers, metadata, and other process RSS.

## Design evidence

| Artifact | Purpose |
| --- | --- |
| `../intake/report_grilling.md` | User decisions, rejected options, and deferred work |
| `reports/requirements-brief.md` | Requirements and repository contracts |
| `reports/report_architecture.md` | Process and capture architecture, failure handling, and data flow |
| `reports/report_interfaces.md` | IF-1 through IF-5 topic, stream, configuration, and FFmpeg contracts |
| `reports/api-endpoint-contracts.md` | Local VisionIPC/ZMQ and cereal pub-sub endpoint inventory and consumer contracts |
| `reports/delivery-plan.md` | Single delivery slice, dependency order, risks, and acceptance criteria AC-1 through AC-7 |
| `reports/implementation-spec.md` | Exact code surface, build target, focused proof plan, and rollback |
| `reports/security-seed.md` | Trust boundaries and required controls for device configuration, FFmpeg, and local IPC |
| `reports/report_stack-lock.md` | No-new-runtime applicability decision and runtime-check limitation |
| `artifacts/taste_snapshot.md` | Effective Taste snapshot and no-profile evidence |

## Implementation boundary

The one slice appends four `FrameData` arms at cereal ordinals 150–153, four 20 Hz services, VisionIPC stream IDs 7–10 in both enum surfaces, and the `sidecamerad` transport-name allowance. The endpoint contract covers the host-local VisionIPC control/data endpoints and cereal subscriptions; it adds no HTTP API or routable listener. The slice then registers an independently opt-in manager process and implements isolated per-camera workers. The native C++/Cython binding rebuild target is `scons msgq_repo/msgq/visionipc/visionipc_pyx.so`. Rollback is to unset `SIDECAMERAD` and restart the manager; no persistent migration is required.

The approved scope excludes native `camerad` changes, model/UI/loggerd/encoderd consumers, network listeners, external or persistent image sinks, auto-discovery, camera transforms, and cross-camera synchronization. Timestamps use host monotonic time with the nominal 50 ms SOF-to-EOF offset; this does not promise hardware timing or synchronization between cameras.

## Acceptance and unresolved risks

AC-1 through AC-7 in the delivery plan are the build acceptance source. A prior one-camera capture is reported at 20 fps for five minutes, but its raw recording is not present in this run. It is not evidence of concurrent performance. Four-camera cadence and CPU headroom remain unmeasured; the 30-minute target-hardware soak in AC-4 is required before four-camera performance sign-off.

The security seed requires validating each configured path, passing it only as data to a fixed direct FFmpeg argv with no shell, limiting workers/threads/buffers, accepting only complete fixed-size frames, closing and reaping failed children, retrying with capped per-camera backoff, retaining the unprivileged identity, and keeping IPC local. Whether the target can enforce child memory/CPU limits safely remains open; if unavailable, the build must report the residual decoder-resource exposure for owner/security review.

The project runtime detector ran from `/data/openpilot` but its bounded 10 MB walk stopped early and did not classify the project stack. Python 3.12.3 is supported by the checkout's `pyproject.toml` range (`>=3.11,<3.13`); the separate harness recommendation is not a project runtime requirement. The stack decision is based on the scoped design adding no runtime, framework, or package, as the user required.

**Taste status:** both project and global stores were rechecked read-only at revision 0 and remain absent; no profile applies.  
**Phase skip:** UI and visual design-system work are not in scope because this is a backend-only process and IPC change; the sanctioned no-user-facing-surface applicability record is in the manifest.
