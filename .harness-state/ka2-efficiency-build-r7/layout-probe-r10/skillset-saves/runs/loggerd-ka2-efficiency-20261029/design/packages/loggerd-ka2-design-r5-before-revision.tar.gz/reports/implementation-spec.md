# Implementation Spec — KA2 loggerd and encoderd lossless correction

**Revision:** r5  
**Design package revision:** r5 (not yet gate-approved)  
**Target:** KA2 / RK3588 (`arch=larch64`, `device=KA2`), existing C++/SCons runtime plus Python manager/test tooling; no new framework. `check_runtime.py --detect-project` was attempted with Python 3.13 but ended incomplete at its project byte limit and found no supported runtime classification signal. No version/stack is inferred from that failed scan; Commander owns the unchanged-stack lock.  
**Read-only target identity:** Parent inventory reports an AArch64 `5.10.198` kernel and AArch64 loggerd/encoderd. `ldd system/loggerd/encoderd` resolves the loaded old 2024 MPP runtime to `/usr/lib/aarch64-linux-gnu/librockchip_mpp.so.0` (SHA-256 `ea762b7da71b63a73cdf14d053d84b091654aee5e5c4f26ceb1449b8fb8d92f9`). RGA resolves via `/lib/aarch64-linux-gnu/librga.so.2` to `/usr/lib/aarch64-linux-gnu/librga.so.2.1.0`, dated 2024-04-06, SHA-256 `ac7ff09a1d428e998db98198cf2a5b4451aa804c2f740487a0be7abfbc993c1c`; this preliminary path/hash is identity only, not proof of the object mapped by an exact launch process or of RGA behavior. `/dev/mpp_service` exists. SConstruct places `/usr/local/lib` before `/usr/lib/aarch64-linux-gnu` and adds `/usr/local/include/rockchip`; `/usr/include/rockchip` is absent. SConstruct sets `RPATH=[]`, and inspected current binaries have no RUNPATH/RPATH, but runtime resolution selects the old `/usr/lib` MPP. Compile headers and `/usr/local` MPP are newer 2026 material; `/usr/local` MPP SHA-256 `b2a64906d97585475a2f1130b7de3276ae712100772ef412cb991c7198c9fe20` is not loaded. `ldd -r` and EOS/meta exports are ABI/symbol clues only. The loaded image lacks a `KEY_INPUT_IDR_REQ` string; this does not prove whether another force-IDR API exists. The exact loaded API/version, EOS completion, force-IDR behavior, and queue/writer behavior remain unproven. Current loggerd executable file SHA-256 is `6c6c13656f4f5abd1de1f31b9c3acb4debc6cc58c4d1aab9a790c46b5b367ed8` and encoderd file SHA-256 is `a46f1c853094b8cf85cfd6533f874cb65047d6c99fd87e215aa0c762ba860b6d`; these are current file identities, not launch-time process fingerprints. S0 must re-pin loaded MPP/RGA paths and hashes against the exact launch processes, pair those with exact built/launched binaries, SConstruct link configuration, and headers, resolve the old MPP API/version, and infer no behavior from identity alone. Do not infer target support from newer headers, `/usr/local`, or upstream develop documentation.  
**Architecture:** `reports/report_architecture.md` @ `d4f58e8e616b211e809b1006692b7632f1d26b62ec843bf87fde5ca1408aac8a`  
**Interfaces:** `reports/report_interfaces.md` @ `c8306fb91ada0009f7ce56c430a574c8183a2f2bcbc7728516e04bbe166ccbd7`; typed set `artifacts/interface_set.json` @ `20e29bfffc101ae79597273ee997a76defdad86b6962755a6bd3bfb97fceb43a`  
**Plan:** `reports/delivery-plan.md` @ `0376f0cea4d71bbf3f1b3ae91c6300db5afdc6a66e6f6423f4ddf44e302fcd30`  
**Research:** `reports/report_research.md` @ `3ef28ea61975967b2f34a4a80b56e17ab481b6a488ed36cce9f60887735af04b`  
**Security seed:** `reports/report_security-seed.md` @ `a6ae465a411268697101480e37185072f6b931141013a7e86d5d5a25b2b47071`

## Slice order

| # | Slice id | Depends on | Ships behind | Acceptance owner |
| - | --- | --- | --- | --- |
| 0 | `slice.loggerd.feasibility` | r5 design-to-build and matching fresh Admiral cross-stage approval; D-6 idle-test authorization | No product feature or source change; capability probe only in isolated run evidence after fresh preflight | Commander / Admiral |
| 1 | `slice.loggerd.copy-lossless-lifecycle` | S0 proved every prerequisite; no guessed EOS or queue contract | Copy-mode runtime behavior and explicit test-only diagnostics | Build owner / Admiral |
| 2 | `slice.loggerd.copy-reference` | S1 passes whole-process D-16, D-13 output and stall gates | Hashed run-scoped reference evidence only | Build owner / Admiral |
| 3 | `slice.loggerd.candidate-correctness` | S2 corrected-copy reference; profile evidence supports a bounded candidate | Existing zero-copy path remains opt-in and default-off | Runtime owner / Admiral |
| 4 | `slice.loggerd.paired-efficiency` | S3 candidate correctness and fresh idle/resource preflight | Paired evidence first; promotion only after a supported gain | Runtime owner / Admiral |
| 5 | `slice.loggerd.loc-minimization` | Correct runtime choice and D-13 behavior settled | One behavior-preserving source/test LOC pass | Build owner / Admiral |

The r3 design phase approval is historical only. The r3 Admiral cross-stage result remains `ESCALATE` and unresolved. The corrected exact-ID test has been run and failed; no implementation, additional test run, STOP/DRAIN probe, or performance work is authorized by this spec until r5 design and a matching fresh Admiral cross-stage gate pass. D-6 currently authorizes bounded isolated synthetic correctness work on the idle production KA2 only; recheck idleness, process/device use, isolation, and ceilings before every runtime invocation.

## Slices

### `slice.loggerd.feasibility`

**Modules owned:** No product modules. The build owner records target source/API, capability probe, and sizing evidence under the active run's build evidence. No manager source is in scope.

**Depends on:** r5 design-to-build and matching fresh Admiral cross-stage approval, then a fresh D-6 idle/ceiling preflight. Each prerequisite is required because the probe touches the production KA2 MPP device even though inputs are synthetic.

**Data / migration changes:** None. Do not add Params keys, services, product diagnostic files, or source changes in this slice.

**Contract tests:** S0 feasibility matrix from architecture AC-13 / planner AC-13. Pair the exact SConstruct build/link configuration and compile headers with hashes for the built and launch-time loggerd/encoderd binaries and the MPP/RGA objects actually mapped by those processes. Re-pin the loaded /usr/lib/aarch64-linux-gnu/librockchip_mpp.so.0 and runtime RGA path/hash; the preliminary RGA symlink identity is not launch evidence. Resolve the loaded 2024 MPP API/version against matching source/package data; newer /usr/local headers/libraries, ldd -r, and exported symbols do not establish target behavior. Prove a supported EOS/completion operation and observable success signal, nonempty output for every accepted ID, zero pending work, and first-input/segment IDR behavior on the loaded image. Establish exact conflate=false ring capacity, cadence, slot reuse, buffer lease/copy lifetime, and maximum supported pause so every frame is secured before producer-slot reuse. Record current loggerd queue/writer source semantics, including the 200-message per-service drop-oldest cap and eight-entry MPP metadata cap; derive defensible encoded-message bounds, raw/future frame and byte caps, and total RSS plus supported DMA/device-memory headroom below the 80% abort threshold. S0 records only the static manager signal/wait order and existing timeout. It does not prove behavior of the unimplemented future FIFO, loggerd/encoderd drain, manager-driven shutdown, or request-to-commit timing; those are S1/AC-14–AC-16 obligations.

**Proof plan:** Re-run read-only build/link and loaded-object identity resolution, pairing the exact built/launched binary hashes with the actual MPP/RGA mappings. Re-pin the RGA identity against the launch process and resolve the old loaded MPP API/version before any probe. If source and matching target-package evidence cannot establish a required EOS/IDR capability, write and hash a one-shot direct-MPP synthetic capability probe and input fingerprint, then run it only after both gates and a fresh idle/ceiling preflight. Keep this probe limited to exact-image MPP capability and output completion; it is not a loggerd/encoderd regression, future-FIFO test, manager-stop test, D-13 reference run, or performance sample. Use source inspection for current queue/writer facts, sizing formulas, and the static manager signal/wait order. Any unknown or infeasible MPP, IDR, ring, packet bound, queue-cap, or memory prerequisite is S0 STOP before implementation. Dynamic future-FIFO classification/order/replay, loggerd drain, manager-driven shutdown, and request-to-commit timing belong to S1 after those behaviors exist. This is a capability/source-evidence slice; product-code TDD is not applicable.

**Rollback:** No product change to revert. Preserve hashes and the failed/unknown evidence. A STOP ends the candidate path; it does not waive D-16 or approve restoring the old lossy behavior.

**Acceptance evidence:** One version-pinned S0 report with hashes for the exact build/link and loaded target objects, MPP/EOS and IDR capability evidence, VisionIPC ring/lease/pause bounds, current queue/writer source facts, packet/capacity formulas, memory headroom, and the static manager order/timeout. Include the exact hashed direct-MPP probe command/output if needed. Mark every S0 prerequisite proven or STOP; do not require an S0 manager-drain run. Accepted by Commander and Admiral.

### `slice.loggerd.copy-lossless-lifecycle`

**Modules owned:** `system/loggerd/encoderd.cc`, `system/loggerd/encoder/mpp_encoder.cc` and `.h`, `system/loggerd/loggerd.cc`, relevant writer code only if its existing completion semantics cannot support the contract, and the focused `system/loggerd/tests/test_loggerd.py` regression. Do not change manager source unless a separate reviewed decision expands scope; do not modify unrelated loggerd utilities or non-KA2 encoders.

**Depends on:** S0 proves the loaded-image EOS/IDR capability, VisionIPC ring and pause bounds, current queue/writer facts, packet-size and capacity limits, memory headroom, and static manager order. S0 does not prove the newly implemented future FIFO or signal-driven drain; those behaviors are built and tested in S1. This dependency prevents build from guessing the target bounds or changing the manager contract.

**Data / migration changes:** No persistent schema migration. Introduce the r5 versioned, transaction-scoped Params request and per-service acknowledgements only as specified in IF-4; use a coherent serialized request, route/process generation, monotonic epoch, fixed service allowlist, and strict byte caps. Do not rely on asynchronous `putNonBlocking()` as an ordering barrier. Do not write frame payloads or diagnostics to Params. Test diagnostics are opt-in under both `LOGGERD_TEST=1` and `LOGGERD_TEST_DIAGNOSTICS=1`, confined to a temporary run root. Keep copy mode as the default.

**Contract tests:** IF-2/3/4/5/6/7/9/10 and planner AC-14–AC-16. Retain the direct *EncodeIdx parser. Before execution, hash-pin the synthetic frame/audio fixture and an independent per-frame-ID, per-stream expected-segment schedule. Record the actual submitted ID set I_s and final last_frame_id separately for each source; require every configured output to contain exactly I_s once, in the expected per-stream order and independently predeclared segment. Do not infer expected IDs or segment membership from loggerd output, hardcode 144/145, use the lossy captures as a reference, or let the implementation validate itself. Preserve the saved 144/138 and 145/137 runs only as historical failures. Derive the expected event/index oracle from the hashed fixture, schedule, source semantics, and configured services; compare rlog.zst/qlog.zst contents and D-13 metadata exactly except the source-approved dynamic fields. Compare decoded audio against the generated sample sequence and check rate, channels, timeline, and markers. Decode camera outputs and verify every input-correlated frame marker/ID, timestamp, predeclared segment, keyframe, codec/container metadata, and decodability. AC-17 later establishes the repeated clean-copy reference for complete decoded-pixel/audio equivalence and deterministic-versus-compressed output comparisons before candidate/performance work. Count each source-confirmed drop, skip, recovery, error, queue-cap, MPP, writer, and sentinel failure; missing telemetry or any positive count fails. Exercise the old/target watermarks, bounded future FIFO, replay after COMMIT, FIFO ordering, writer finalization, and drain-to-zero. Finally exercise the real manager stop sequence: nonblocking SIGINT to loggerd then encoderd, followed by encoder-first blocking waits. Loggerd must remain available through final encoder watermarks, consume/write and finalize sentinels, publish its final-write acknowledgement, then exit; encoderd exits only after that acknowledgement. Require both normal exits within one shared 4500 ms CLOCK_BOOTTIME deadline (<5 seconds), with manager source/order/predicates/timeout unchanged. This is an S1 hard gate, not an S0 prerequisite.

**Proof plan:** Preserve the two saved lossy copy-mode runs as distinct failures and do not rerun them or use them as a baseline. After S0 and the approved design/cross-stage gates, build the S1 implementation and instrument input/accepted/submitted/published/consumed/written watermarks, per-stream CLOCK_BOOTTIME gaps/latency, queue depths/bytes, and MPP pending counts. Run the isolated corrected-copy regression with the hash-pinned fixture and independent frame-ID segment oracle. Assert whole-process D-16 from first input through teardown, the fixture-derived D-13 event/audio/video checks, input gaps <3000 ms, output gaps/latency/request-to-commit <1000 ms, zero watchdog/recovery/drop/writer errors, bounded non-growing queues, and drain-to-zero. Exercise the actual ManagerProcess stop sequence concurrently, not a sequential harness approximation; measure from loggerd's first SIGINT through both child exits and require the one shared 4500 ms CLOCK_BOOTTIME deadline to pass strictly inside the unchanged five-second timeout. Any failure blocks S2 and all candidate/performance work. AC-17, not S1, runs at least three clean copy captures to establish the repeatable reference and full decoded-media equivalence. Keep isolated temporary log/Params/IPC roots, preserve failed evidence, and do not add a maintained benchmark runner.

**Rollback:** Revert the S1 change as a unit if any ID, watermark, writer/sentinel, timing, memory, or cleanup assertion fails; preserve run output and counters. Rollback leaves the task unqualified because the pre-change copy path is already known to lose frames; it does not make the old behavior acceptable. Do not promote zero-copy or sample performance after a failure.

**Acceptance evidence:** Hash-pinned diff and exact-target build evidence; corrected-copy regression using target-supported tooling; independent fixture/schedule hashes; exact expected/emitted ID and segment ledger; D-13 event/index and decoded audio/video checks; per-source drop/error counters; per-stream timing/backlog traces; startup, rollover, recovery and shutdown watermarks; queue/MPP drain-to-zero; and the actual concurrent manager-stop proof with loggerd and encoderd normal exits inside the shared 4500 ms deadline. Acceptance belongs to build owner and Admiral. Both historical copy runs remain lossy; the corrected exact-ID run failed, and no runtime pass is claimed by this design.

### `slice.loggerd.copy-reference`

**Modules owned:** No product modules. Build evidence only under the active run path; no checked-in benchmark tool.

**Depends on:** S1 passes every D-16 lifecycle ID gate, D-13 output equivalence, stall, queue, writer and cleanup gate. A lossy run cannot be a comparator.

**Data / migration changes:** None. Pin exact binary/source/configuration hashes, synthetic fixture hash, Params seed, service selection, dimensions/FPS/codec settings, and supported DMA reader (if any). Keep settings identical between arms.

**Contract tests:** Planner AC-17. Run at least three repeat copy captures to establish deterministic or nondeterministic media encoding and a clean corrected-copy output oracle. For `rlog.zst`/`qlog.zst`, compare byte-for-byte after canonicalizing only documented run-varying `Event.logMonoTime`, `EncodeData.unixTimestampNanos`, `InitData.wallTimeNanos`, timestamp-derived route UTC name, and numeric `df -h` fields; validate their clock domains and bounds. Preserve all other data exactly, including SOF/EOF, IDs/index order, sentinels, segment/file boundaries, audio samples and metadata. Decode camera outputs and compare ordered identities/pixels, timestamps, segment mapping, codec/container metadata and decodability. Record encoded media hashes/byte deltas; hash variance alone is acceptable only when repeated corrected-copy runs establish compression nondeterminism and decoded content still matches.

**Proof plan:** Reuse the focused isolated test as the exact behavior gate; save a run-scoped standard-library comparison command, input fingerprint and hashes before repeated captures. Command and comparator script must be written under run-scoped build evidence after S1; the specification does not add or imply a maintained product runner. No resource sampling occurs in this slice. If repeat outputs differ outside allowed clock/disk fields or any whole-run frame ID is absent, duplicated, extra, stalled, or unaccounted, reject the reference and return to S1.

**Rollback:** No code rollback. Discard the invalid reference package, retain the failed raw evidence, and fix S1 before restarting S2.

**Acceptance evidence:** Three pinned corrected-copy captures; hashes for input, binaries, settings, Params seed, run-scoped command/comparator, raw output and parsed ledgers; verified D-13 comparison and all timing/watermark gates. Accepted by runtime owner and Admiral.

### `slice.loggerd.candidate-correctness`

**Modules owned:** Existing opt-in KA2 candidate in `system/loggerd/encoder/mpp_encoder.cc` and the focused test only if candidate-specific diagnostics are missing. No default change in this slice.

**Depends on:** S2 establishes a clean repeated copy reference and exact MPP build. Profile evidence must identify a bounded candidate hypothesis before implementation; do not change pool depth, output settings, queue structure, or ownership without a fresh design revision.

**Data / migration changes:** None. `ENCODER_ZERO_COPY` remains unset-default copy; preserve current parsing (`atoi(value) != 0 && !is_downscale`) and `=0` copy override exactly.

**Contract tests:** Planner AC-18 and IF-7/9. On the exact KA2 build, test the existing opt-in zero-copy path for eligible streams with a deterministic textured, frame-ID-marked NV12 fixture precomputed identically for both modes. Inject import failures beginning at the first failure through the existing 64-consecutive-failure fallback threshold, and test successful import with empty payload. Require exact expected-vs-emitted IDs from first frame through teardown, zero encode/drop/recovery/writer errors, complete decoded content and D-13 equivalence, pending/drain-to-zero and timing/backlog gates. Existing source has early import-failure risk before the copy pool is allocated, and successful empty packets may be skipped without fallback; any such result rejects zero-copy.

**Proof plan:** Use the focused functional regression first, then the candidate-specific failure-injection run after fresh idle/ceiling preflight. Keep correctness fixture separate from the later timed textured workload if they have different purpose, but identical precomputed bytes within a paired comparison. Do not perform paired resource sampling until every correctness case passes. Preserve all failure artifacts. The observed focused command is `pytest system/loggerd/tests/test_loggerd.py::TestLoggerd::test_ka2_deterministic_rotation_alignment -q` (Python 3.12.3 in `/usr/local/venv/bin/python`); validate target-supported pytest tooling and interpreter before any future run. Any additional run-scoped injector command is hashed separately in evidence.

**Rollback:** Set `ENCODER_ZERO_COPY=0` or leave it unset to retain copy mode and reject the candidate. Do not alter fallback semantics or the default to compensate for an incomplete candidate. A failure leaves optimization work unqualified.

**Acceptance evidence:** Exact-build fingerprint, injected-failure matrix and direct counters, exact ID ledger, decoded-content/media metadata comparison, D-13 output check, drain/timing/backlog/memory evidence, plus independent profile attribution for the candidate. Accepted by runtime owner and Admiral.

### `slice.loggerd.paired-efficiency`

**Modules owned:** Run-scoped evidence tooling only until the measurements justify a later default-selection edit. If promoted, only `system/loggerd/encoder/mpp_encoder.cc` changes for the unset default; do not change manager source or unrelated implementations.

**Depends on:** S3 candidate correctness and fresh idle/resource preflight. Both copy and candidate arms must use the same exact build, synthetic textured fixture, settings, service set and Params seed. No arm may have any hard-gate failure.

**Data / migration changes:** None. Fixed bitrate, resolution, FPS, camera/audio selection, codec, segment, manager and log semantics remain unchanged.

**Contract tests:** Planner AC-19/20; D-15. The run-scoped benchmark command/fixture/fingerprint are hashed before launch, outside timed windows. Perform three warmups per mode, five pilot pairs, then 30 randomized interleaved measured pairs, each 2 seconds with at least one short rotation boundary. Report medians, p95/p99 and paired 95% intervals for per-stream input gaps, output gaps, encode latency, CPU/frame, process RSS, and supported DMA/device memory separately. Pre-register estimator and seed and independently recompute from raw samples. Keep hard D-16, D-13, zero-stall, non-growing-backlog, queue-drain and cleanup checks on every warmup, pilot, and measured arm. Stop at 10 minutes total, 768 MiB generated logs/video, 80% existing critical-memory threshold, thermal throttling, or any newly competing workload. If DMA/device memory has no supported reader, state unavailable and limit the claim to measured RSS.

**Proof plan:** Correctness pass precedes sampling. Use only a hashed run-scoped standard-library driver; do not create a maintained test/benchmark script under `system/loggerd/tests`. A claim requires at least one CPU or memory paired CI favorably excluding no change and no supported regression in other resource or p95/p99 timing metrics. Only after this condition may Commander/Admiral consider S4 unset-default promotion; the promoted unset build must repeat exact ID/output/stall tests. Report LOC separately.

**Rollback:** If any pair fails correctness or a confidence interval shows regression/no gain, keep copy default and retain the failed samples. If promotion fails post-change D-16/D-13, revert only the default-selection diff to copy and mark promotion rejected. Reverting does not waive the candidate hard gates.

**Acceptance evidence:** Raw paired samples, run-scoped command and fixture hashes, target/build fingerprint, idle/ceiling preflight, all correctness logs, CI recomputation, per-stream tail summaries, CPU/RSS/device-memory accounting, and—if promoted—post-promotion exact output checks. Accepted by runtime owner and Admiral.

### `slice.loggerd.loc-minimization`

**Modules owned:** One pass over the scoped KA2 loggerd/encoderd runtime path (shared code and MPP) and affected tests only. Exclude manager source, unrelated utilities and unsupported platform implementations.

**Depends on:** Correct behavior and selected runtime mode settled; all relevant D-13/D-16 and resource checks available. This pass cannot repair an unqualified no-loss path.

**Data / migration changes:** None.

**Contract tests:** Planner AC-21 and D-14. Record per-file production/test LOC before and after separately. The optional `system/loggerd/encoder/encoder.cc` publish simplification to `PubMaster::send(..., MessageBuilder&)` is eligible only if the overload is byte/output equivalent; it is LOC-only. Retain no edit that harms clarity, raises risk, changes behavior, or regresses measured CPU/memory or p95/p99 metrics.

**Proof plan:** Review the scoped diff once, prove overload serialization/send equivalence where applicable, then run the affected build, exact D-13/D-16 output/timing checks, and applicable paired resource comparison. If there is no safe reduction, make no edit and report no LOC gain. One focused command after an accepted edit is the same targeted regression command used for S1; resource comparison is attached only when runtime behavior could change.

**Rollback:** Revert the LOC-only diff on any behavior/build/resource regression; retain the already-qualified runtime selection. If no proof is available, leave code unchanged and report “unverified; no LOC gain.”

**Acceptance evidence:** Touched file inventory, per-file production/test LOC counts and deltas, accepted/rejected edits, build/output proof and applicable no-regression resource evidence. Accepted by build owner and Admiral.

## Dependency graph

```text
r5 design gate + matching fresh Admiral cross-stage gate + D-6 idle preflight
  └── S0 exact-target feasibility (any unknown/failure => STOP, no implementation)
       └── S1 copy-mode lifecycle correctness + diagnostics (D-16 and D-13)
            └── S2 corrected-copy reference (repeat output equivalence)
                 └── S3 candidate correctness/profile (zero-copy stays opt-in)
                      └── S4 paired resource evidence (conditional unset-default promotion)
                           └── S5 one LOC pass (separate maintainability report)
```

## Operational constraints

| Constraint | Slices | Owner | Removal criterion |
| --- | --- | --- | --- |
| No implementation until r5 design and matching fresh Admiral cross-stage approvals | S0–S5 | Admiral | Matching r5 verdicts recorded; r3 ESCALATE remains historical |
| S0 loaded old MPP API/EOS completion, exact binary/runtime linkage, queue/FIFO/memory caps, VisionIPC ring retention and IDR evidence | S0–S1 | Build/runtime owner | Hash and resolve the loaded `/usr/lib/aarch64-linux-gnu/librockchip_mpp.so.0` and linked runtime images; prove every exact target prerequisite; any unknown/failure stops candidate |
| STOP_DRAIN must fit the five-second non-camerad ManagerProcess stop period with loggerd still consuming; manager source remains unchanged | S0–S1 | Build owner / Commander | Measured and source-backed proof; otherwise separately reviewed scope or stop |
| `<3000 ms` input gaps; `<1000 ms` output gaps, encode latency, rotation drain/commit | S0–S4 | Build/runtime owner | Every qualifying run passes direct CLOCK_BOOTTIME instrumentation; thresholds are not assumed |
| Fresh idle/ceiling preflight; temporary log/Params/IPC/diagnostic roots; no camera/sensor/I2C/on-road/prod roots | Any runtime slice | Runtime owner | Required before every invocation; stop on competing workloads or ceiling |
| 10-minute/768-MiB/80%-memory/thermal limits | S0/S1/S3/S4 | Runtime owner | Fixed by Intake; a ceiling abort is not a pass |
| Copy stays default until S4 measured gain and post-promotion gates pass | S1–S4 | Admiral | Exact AC-19/20 approval; otherwise copy stays default |
| No bitrate/resolution/FPS/audio/camera/schema/segment/manager changes | S0–S5 | Build owner | Not removable in this revision |

## Non-goals

- Do not treat either saved lossy copy run (138/144 or 137/145 emitted) as a qualifying baseline or any speedup evidence.
- Do not waive startup, first-keyframe, rollover, recovery, teardown or shutdown IDs, and do not accept parity with a lossy baseline as D-16 compliance.
- Do not claim the PREPARE/DRAIN/COMMIT protocol is bounded before exact target MPP completion, ring retention, queue/writer behavior, memory headroom, IDR, timing, and manager shutdown evidence pass.
- Do not reduce bitrate, resolution, FPS, camera/audio selection, or alter segment/schema/uploader/retention behavior.
- Do not enable zero-copy by default before exact-build D-16/D-13 and paired gain; do not redesign pool depth or queue ownership without profile evidence and a new design revision.
- Do not add a maintained benchmark runner or invasive DMA instrumentation; save one-off standard-library tooling and artifacts under the run path.
- Do not modify manager source in this scope. If the existing five-second window/order cannot support no-loss teardown, stop and obtain separate review.
- Do not claim any test pass, runtime result, speedup, memory reduction, or production readiness from the design artifacts.

## Blocking decisions

| Decision | Owner | Blocks slices | Latest safe decision point |
| --- | --- | --- | --- |
| Exact deployed MPP EOS/completion and empty-pending proof | Build/runtime owner / Admiral | S0–S1 | Before implementation or a STOP/DRAIN run |
| VisionIPC ring depth/cadence and max pause retention | Build/runtime owner / Admiral | S0–S1 | Before implementation or a STOP/DRAIN run |
| Frame/byte queue cap and RSS/DMA headroom below 80% threshold | Build/runtime owner / Admiral | S0–S1 | Before implementation or a STOP/DRAIN run |
| Initial and segment IDR/first-frame behavior on target build | Build/runtime owner / Admiral | S0–S1 | Before implementation or a STOP/DRAIN run |
| Request-to-commit and output gaps below 1000 ms | Build/runtime owner / Admiral | S0–S1 | Before another rotation/drain run |
| Manager stop order and STOP_DRAIN inside the five-second window | Build owner / Commander / Admiral | S0–S1 | Before claiming process-lifetime zero-loss; otherwise separate manager review or stop |
| Corrected copy reference passes D-16 and D-13 | Build/test owner / Admiral | S2–S5 | Before any candidate performance comparison |
| DMA/device memory reader availability | Runtime owner / Admiral | S4 | Before resource claims; report unavailable if unsupported |
| r3 Admiral cross-stage `ESCALATE` and external save-root eligibility | Admiral | Any build release under r5 | Remains unresolved; r5 requires a matching fresh cross-stage decision |

## Return

Return this spec to `design/commander` for stack-lock reconciliation, package assembly, Taste recheck, design package checks, and `gatekeeper-design`. It does not authorize source implementation, a new native-process test, STOP/DRAIN probe, MPP workload, performance sample, default promotion, or LOC edit before the required matching gates and S0 preconditions.
