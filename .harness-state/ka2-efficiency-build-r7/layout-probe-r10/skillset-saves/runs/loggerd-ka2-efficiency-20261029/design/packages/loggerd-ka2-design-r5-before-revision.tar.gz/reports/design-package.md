---
submission_id: loggerd-ka2-efficiency-20261029-design-r5
revision: r5
---

# Design package — KA2 loggerd and encoderd lossless correction and efficiency

**Boundary:** design-to-build  
**Run:** `loggerd-ka2-efficiency-20261029`  
**Submission:** `loggerd-ka2-efficiency-20261029-design-r5`  
**Revision:** r5

## Status and decision

R5 incorporates two separate synthetic copy-mode failures against the user's hard D-16 rule: every submitted camera ID must appear exactly once through teardown, with no startup, keyframe, rotation, recovery, or shutdown waiver. Neither run establishes a qualifying baseline. The next design/build step is to correct and prove copy-mode behavior before considering efficiency candidates. There is no measured CPU, RSS, DMA/device-memory, or latency improvement and no product runtime change in this package.

R4's design gate returned `REVISE` on the manager-driven SIGINT drain contract, S0/S1 feasibility split, and independence of the first segment-map oracle. R5 addresses those findings: S0 is limited to pre-code static/API/ring/queue/memory feasibility and the static manager order; actual concurrent SIGINT drain, implemented queue replay, and output high-water proof are S1 gates before S2. The S1 oracle uses a deterministic frame-ID segment schedule declared before launch, independently of the lossy captures and S2. No r5 phase verdict is claimed until Gatekeeper Design returns one. The prior r3 phase approval is historical; the separate r3 Admiral cross-stage `ESCALATE` remains unresolved and is not an approval. The prior validator run used the source-checkout root, while this run's canonical save tree is physically stored at `/data/media/supremeteam/42c6eb550c629191187c/skillset-saves`. Admiral has prechecked containment from that canonical root; r5 design self-checks will run there. No r5 phase or cross-stage approval is claimed until its designated validators pass.

D-6 authorizes bounded synthetic correctness tests on the user-confirmed idle KA2 after fresh idleness, ownership, isolation, memory, thermal, and output-ceiling checks. It does not authorize live camera/sensor input, I2C, on-road capture, or writes to production log/Params roots. A matching fresh Admiral cross-stage APPROVED verdict is required before build work. The prior r3 verdict remains ESCALATE because its handoff named r2 while its design manifest named r3, and its shape validator rejected the symlink-resolved save path when run from the source-checkout root. Admiral has prechecked containment from the canonical media save root; a future r5 package-shape/cross-stage check must run from that root and its result must be recorded. This precheck does not replace the cross-stage verdict. Do not rerun against the prior rejected path, implement a candidate, or run performance sampling before the fresh matching gate.

## Launch path and behavior under review

Manager registers loggerd as `./loggerd` from `system/loggerd` under the logging predicate, normal encoderd as `./encoderd` under `only_onroad`, and stream mode as `./encoderd --stream` under `notcar`. These `NativeProcess` registrations do not set `restart_if_crash`: manager state reflects a child exit, but the child is not automatically retried until a lifecycle stop/restart cleanup. On KA2, loggerd is the segment clock and Params authority; its rotation check runs after a processed subscribed message, so a total message-silence loop delays the boundary check. Encoderd consumes camera VisionIPC, encodes camera/audio streams, and publishes cereal `EncodeData`; loggerd consumes encoded events and writes route logs and media segments.

For `arch=larch64, device=KA2`, the build selects `encoder/mpp_encoder.cc` and Rockchip MPP/RGA. Copy mode remains the default and uses six preallocated frame buffers per stream. Zero-copy is opt-in. Its current fallback covers repeated import failures only; an early import failure can fail before the copy pool exists, and a successful import that produces an empty HEVC packet appears to drop output without automatic fallback. `MppEncoder::encoder_close()` currently does not submit EOS or verify that pending metadata is empty; `drain_packets(false)` can stop at the first unavailable packet and return success, after which close clears pending metadata. These source observations are reasons for proof gates, not claims that a drain is bounded.

The source review and launch behavior are detailed in [research](report_research.md), [architecture](report_architecture.md), and [interfaces](report_interfaces.md). The revisioned typed interfaces are in [interface_set.json](../artifacts/interface_set.json).

## Observed regression evidence

The earlier 2026-10-30 01:25 parser-mismatch run submitted IDs 1–144 on each camera stream and emitted 138 unique IDs per output. It missed startup IDs 1 and 2 and additional rollover-adjacent IDs: road/driver/qRoad missed `[99, 101, 102, 103]`; wideRoad missed `[99, 100, 102, 103]`. That test version searched qlogs for `*EncodeData` while the output is `*EncodeIdx`; the raw logs were parsed offline. This is a failed observation, not an oracle pass.

The corrected run at 2026-10-30 02:30 UTC invoked `pytest system/loggerd/tests/test_loggerd.py::TestLoggerd::test_ka2_deterministic_rotation_alignment -q` under Python 3.12.3 and exited 1 after 12.77 seconds (8.83 seconds in the test call). It submitted 145 IDs, 1–145, on each road/wideRoad/driver source and 145 rawAudioData events. Each of road, wideRoad, driver, and qRoad emitted 137 unique IDs, with no duplicates or extras:

| Output | Missing IDs |
| --- | --- |
| `roadEncodeIdx` | 1, 2, 100, 101, 102, 104, 105, 106 |
| `driverEncodeIdx` | 1, 2, 100, 101, 102, 104, 105, 106 |
| `qRoadEncodeIdx` | 1, 2, 100, 101, 102, 104, 105, 106 |
| `wideRoadEncodeIdx` | 1, 2, 100, 101, 102, 103, 105, 106 |

The direct assertion stopped at wideRoad; remaining output sets were parsed offline. Its 97/40 per-segment counts came from elapsed-time rotation, not a predeclared frame-ID schedule, and do not satisfy the future AC-15 oracle. `ffprobe` found an H.264 stream and mono AAC 16 kHz track in segment 0 (4.85 s and 5.12 s); this proves track presence only. The test stopped before its audio-content assertion, so no audio sample equivalence or continuity proof exists. Neither capture independently instrumented input-to-output latency or backlog. The single short-run qlog gap observations below 1 second do not prove no stalls. Source inspection identifies mechanisms consistent with rollover loss, but the captured runs do not directly attribute each missing ID to a specific drop site.

The second run's expected/emitted and raw-log evidence is preserved under `build/evidence/rerun_20261030_023059/`; the refreshed test report is under `build/reports/`. The source hash is `fc55ae0129598d5a0dff0e62160522bffa86502410392dbd37202d4ca01cf6ac`, run summary hash `3c4cd258f8b8a5f9e0f7d4c1f8d7087c0967491338d71af2b2198a97f6a75179`, raw 580-row CSV ledger hash `27625d6c70829ffd8fb8b46cfceaa5843d712cc3bc5ed6946598a70a6d0557c5` (canonical content hash `82e18f684b2b086e22d9da3f496a1bcecf5032863ee40c2b89a47d19abf6fb9a`), and test report hash `09aab13bdf40308c31aafe2b9be99736dca02a2493f0ebd2524aee079e5447f9`. Raw per-segment qlog/rlog hashes are recorded in the run summary. Preflight and postflight found AArch64, the `/KA2` marker, `/dev/mpp_service`, no loggerd/encoderd/camerad, and no MPP holder. Offline sizing found the 12 generated segment files total 135,227 bytes (about 0.129 MiB); this is post-run output evidence, not proof that a preflight limit was enforced. The preserved evidence does not record free/critical memory or thermal checks; all are required, along with output-ceiling enforcement, before any future target workload. No runtime fix or resource sample was made.

## Required behavior and output oracle

For each source stream `s`, derive the exact submitted ID set `I_s` from that run's first generated input through final teardown. Each configured output mapped to `s` must equal `I_s` exactly once, with no omissions, extras, duplicates, or unaccounted frames. Use `1..N_s` only when the captured input set is contiguous from 1; `N_s` is the actual last submitted ID for that run. Startup alignment, first-keyframe handling, rollover, recovery, and shutdown remain inside the gate. A lossy copy baseline fails and cannot qualify an optimization candidate.

The S1 schedule must assign each logical frame ID to an expected segment before launch, using a test-only deterministic boundary keyed to frame IDs and the loggerd segment-authority contract. It must not derive expected assignments from elapsed-time output, the current lossy run, or the later S2 comparison. Compare every emitted `EncodeIdx` and media/audio/log result against that independent map. Startup skips and first-keyframe behavior are recorded, but parity with a lossy baseline does not waive D-16.

Zero loss and zero stalls are independent gates. Require exact input/output/writer/final-watermark accounting, zero watchdog/recovery/drop/encode/writer errors, input gaps below 3000 ms, output gaps and encode latency below 1000 ms, rotation request-to-commit below 1000 ms, no growing backlog or cap saturation, and all MPP/FIFO/loggerd work drained to zero. Instrument all known drop/error sites; missing telemetry or any unexplained discrepancy invalidates the run. Include writer finalization and sentinels at shutdown.

D-13 output comparison preserves existing log and media behavior. Compare `rlog.zst`/`qlog.zst` deterministic event fields byte-for-byte after canonicalizing only source-proven run-varying `Event.logMonoTime`, `EncodeData.unixTimestampNanos`, `InitData.wallTimeNanos`, UTC route-name timestamps, and numeric `df -h` usage. Validate clock domains, per-run bounds, and per-producer/per-stream order; do not impose a global timestamp order on independent producers. Preserve SOF/EOF, IDs, indices, sentinels, segment/file boundaries, other metadata, and `df -h` schema/device/mount rows. Use identical seeded isolated Params. Compare audio samples exactly. For video, require matching decoded identities/pixels, count/order/timestamps, codec/container metadata, segment mapping, and decodability; record media hashes and byte deltas. Only allow encoded hash variance if repeated copy runs prove the compression itself is nondeterministic while decoded output and metadata remain equal.

## Feasibility gates and shutdown contract

S0 is pre-code feasibility only: pin the exact built/launch binary and actually mapped MPP/RGA images; establish the loaded MPP API/EOS and IDR capability; prove VisionIPC ring slots, cadence, buffer-reuse/lease lifetime, and pause tolerance; identify current queue semantics and defensible packet-size bounds; calculate raw-frame/future-message caps and aggregate RSS/DMA headroom; and record the static manager signal/wait order. Current source queue caps and formula-derived limits are not proof of a future FIFO's dynamic replay or high-water behavior.

The inspected runtime resolves MPP to `/usr/lib/aarch64-linux-gnu/librockchip_mpp.so.0` (2024 image, SHA-256 `ea762b7da71b63a73cdf14d053d84b091654aee5e5c4f26ceb1449b8fb8d92f9`) while SConstruct searches `/usr/local/lib` first and uses newer `/usr/local/include/rockchip` headers; no RPATH/RUNPATH is present. The inspected RGA target is `/usr/lib/aarch64-linux-gnu/librga.so.2.1.0` (SHA-256 `ac7ff09a1d428e998db98198cf2a5b4451aa804c2f740487a0be7abfbc993c1c`). These are identity observations only; exact launch mappings and loaded-image behavior must be re-pinned. `ldd -r` proves symbol resolution, not EOS, IDR, or drain behavior. Unknown API support, ring retention, packet bound, or feasible memory headroom means STOP before implementation.

S0 does not assert the behavior of code that is not implemented. Manager currently sends nonblocking SIGINT to all stopping processes in configuration order (loggerd before encoderd), then waits in `VISION_SHUTDOWN_ORDER` (encoderd before loggerd); both signals have already been sent before waits. `ManagerProcess.stop()` gives each non-camerad process five seconds before SIGKILL. S1 must implement loggerd `shutdown_requested` behavior and encoder EOS drain/ack, keeping loggerd consuming/writing until all final watermarks and writer sentinels are complete. The concurrent manager sequence must pass inside one shared 4500 ms CLOCK_BOOTTIME deadline, below the unchanged 5-second stop bound. If it fails, blocks S2 and later work; do not claim sequential test shutdown proves manager behavior or weaken D-16.

The proposed rotation path uses a versioned loggerd-owned PREPARE/DRAIN/COMMIT transaction: encoderd reports per-service old-segment accepted/submitted/published watermarks and pending count; loggerd independently consumes and writes each old watermark, finalizes old writers, then commits. Target-segment messages remain in a bounded future FIFO until commit. STOP_DRAIN applies the same final-watermark/ack rule at teardown. This is a design hypothesis, not a proven MPP flush or queue bound. S1 must measure implemented queue classification, order, replay, high-water, writers, and drain-to-zero before a corrected-copy reference is eligible.

## Efficiency candidates and stop condition

Candidates are conditional on the lossless corrected-copy reference and profile evidence:

| Order | Candidate | Plausible gain | Main risk and acceptance |
| --- | --- | --- | --- |
| 1 | Existing MPP zero-copy path | Largest plausible reduction in CPU copies and memory traffic. | High loss risk: test empty payload and import failure beginning at the first failure through the existing 64-failure threshold. Keep copy default unless exact-build D-16/D-13 and paired resource gates pass; after promoting the unset default, repeat full correctness gates on the default build. |
| 2 | MPP pool depth | Possible DMA/device-memory reduction. | Do not change without exact ownership/in-flight bounds, profile evidence, a measurable gain, and a fresh design revision. |
| 3 | Loggerd queue/serialization/memory paths | No current bottleneck is demonstrated. | No changes without profile evidence and full lifecycle/output proof; do not shrink or evict required data. Fresh design revision required. |
| 4 | One scoped LOC-minimization pass | Maintainability/source-size change only. | After runtime choice, report production and test LOC deltas per file; retain only behavior-preserving edits with no clarity, risk, runtime, or memory regression. LOC is not an efficiency claim. |

Measure only after S2 establishes at least three repeated, pinned, lossless copy captures. Use identical precomputed deterministic textured NV12 input with frame-ID markers; generate it outside timed windows and use the same bytes in paired arms. Run 3 warmups, 5 pilot pairs, then 30 randomized/interleaved 2-second pairs. Report median, p95/p99 and paired 95% intervals for CPU/frame, RSS, available DMA/device memory, and per-stream input gap/output gap/encode latency. Require a CPU or memory interval that excludes no change in the favorable direction and no supported regression elsewhere; every warmup, pilot, and measured arm must pass D-16, stalls, backlog, output equivalence, and timing gates. Run-scoped standard-library tooling and evidence only; no maintained product benchmark runner. Report DMA unavailable if there is no supported reader. Ceilings: 10 minutes, 768 MiB cumulative generated output, thermal stop, and abort before the 80% critical-memory threshold.

Recursive work stops when the current candidate fails any behavior, no-loss, no-stall, memory, timing, output, or quantitative gate; when a required metric is unsupported/unmeasurable; when feasibility is unknown; or when no safe measurable CPU/memory gain remains. Each next runtime candidate requires profile evidence and a fresh design revision. No bitrate, codec/settings, resolution, FPS, camera/audio selection, logging schema, segment semantics, or manager behavior may be changed to manufacture a gain.

## Acceptance sequence

The full ordered criteria AC-13–AC-21 are specified in [delivery-plan.md](delivery-plan.md). Their phase boundaries are:

| Slice | Exit condition |
| --- | --- |
| S0 / AC-13 | Exact-build MPP/EOS/IDR, ring retention, current queues, packet bounds, cap/headroom, and static manager-order feasibility are evidenced. Unknown or failed pre-code prerequisites mean STOP. |
| S1 / AC-14–AC-16 | Correct copy path; test-only instrumentation and independent predeclared segment schedule; whole-process exact IDs, zero loss/stalls, output equivalence, queue/writer completion, and actual concurrent manager-SIGINT drain pass. Any failure blocks S2. |
| S2 / AC-17 | At least three repeated corrected-copy outputs establish a pinned lossless comparator under D-13. |
| S3 / AC-18 | One profile-supported candidate passes full correctness and injected failure cases before measurement. |
| S4 / AC-19–AC-20 | Paired quantitative comparison passes the hard gates; only then may unset-default promotion be considered, followed by a full correctness rerun on the promoted default. |
| S5 / AC-21 | One scoped behavior-preserving LOC review; per-file production/test counts and proof, or explicit no-safe-change result. |

## Phase evidence, skips, and dependencies

| Stage | R5 status and evidence |
| --- | --- |
| Intake | Binding D-13–D-16 in `../intake/report_grilling.md` (SHA-256 `eafbf6eaf3033bc53f7661b2a4fd183f7a57904f5e77a67f04ab60ac72d78f15`) and `../intake/intake-brief.md` (SHA-256 `c5dd92bfc130e339d32ac1fffda73a33235d72ba9e503da6a8f02a75f9453f6a`). |
| Research | Complete r5 source/evidence brief: [report_research.md](report_research.md), SHA-256 `3ef28ea61975967b2f34a4a80b56e17ab481b6a488ed36cce9f60887735af04b`. |
| Architecture / interfaces | Complete r5 source-driven architecture and typed contracts: [report_architecture.md](report_architecture.md), SHA-256 `d4f58e8e616b211e809b1006692b7632f1d26b62ec843bf87fde5ca1408aac8a`; [report_interfaces.md](report_interfaces.md), SHA-256 `c8306fb91ada0009f7ce56c430a574c8183a2f2bcbc7728516e04bbe166ccbd7`; [interface_set.json](../artifacts/interface_set.json), SHA-256 `20e29bfffc101ae79597273ee997a76defdad86b6962755a6bd3bfb97fceb43a`. |
| Security seed | Applicable. The proposed bidirectional Params transaction and sensitive bounded media staging change existing local control/data-retention boundaries; controls are forward-looking, not implementation evidence. [report_security-seed.md](report_security-seed.md), SHA-256 `a6ae465a411268697101480e37185072f6b931141013a7e86d5d5a25b2b47071`. |
| Plan / specification | AC-13–AC-21 and S0–S5: [delivery-plan.md](delivery-plan.md), SHA-256 `a1f72d7fcfe285ed92867be472245a6a44d40981e060029c6097c47eb01fa1ae`; [implementation-spec.md](implementation-spec.md), SHA-256 `25399154e743720e0229f9e090c0458b470f2613d29cb39bf01b4f63b24d1442`. |
| Stack lock | No new runtime, framework, dependency, build configuration, or package. Detector scan was incomplete; no empty-stack claim is inferred. [report_stack-lock.md](report_stack-lock.md), SHA-256 `387f0f923160050c569c221d9aa31aa18da0662f85c51b14e526659d074e4dda`. |
| Taste | No saved profile applies; immutable applicability snapshot is `../artifacts/taste_snapshot.json` (SHA-256 `a8920dd6294be763f8d88fd0257bb41bc5f2f150eaad93ba5ebcacfa035423d7`). Gate-time r5 recheck: [report_taste-snapshot.md](report_taste-snapshot.md), SHA-256 `0a99d6340a13504f1daaab2cc142b2be730477abc5dd02aeef625dfe67421b0f`. |
| API contract | Conditional API endpoint artifact skipped: the design changes only existing local process/Params/cereal interfaces; it adds no network/external API endpoint. API contract check remains a conditional gatekeeper item. |
| UI evidence | Skipped: no user-facing surface. The fallback record is `../artifacts/ui_evidence.json`, SHA-256 `1c02825a604e40c7351f53453a0e10fd1a48dbd37992dcc27d2d7f8543b868da`. |
| Design gate | R4 was REVISE; r5 is pending Gatekeeper Design. No r5 approval is claimed. |
| Cross-stage gate | Historical r3 Admiral verdict remains `ESCALATE`: it paired the r3 design with r2 delivery documents, and its shape validator rejected the symlink-resolved path when run from `/data/openpilot`. Admiral prechecked containment from canonical root `/data/media/supremeteam/42c6eb550c629191187c`, but no fresh r5 package-shape or cross-stage verdict exists. The precheck does not clear the historical escalation. |

## Handoff

If r5 design-to-build is approved, checkpoint that exact phase verdict and refresh Admiral-owned handoff and delivery documents to the same r5 submission. Then run cross-stage checks from the canonical media save root `/data/media/supremeteam/42c6eb550c629191187c`, where the run's physical `skillset-saves/` tree is contained; record the resulting package-shape and cross-stage verdicts. Preserve the r3 escalation as historical. Build Management may begin S0 static/capability work only after a fresh matching cross-stage APPROVED verdict and a fresh idle-target/ceiling check. If S0 cannot prove a required bound, STOP before implementation. If S1 fails exact whole-process coverage or manager-order shutdown, block the corrected-copy reference, all candidates, and performance sampling. No downstream performance or shipping decision is implied by this design package.
