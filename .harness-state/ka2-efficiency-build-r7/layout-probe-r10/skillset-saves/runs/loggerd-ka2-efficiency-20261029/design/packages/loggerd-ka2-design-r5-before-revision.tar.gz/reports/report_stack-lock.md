---
submission_id: loggerd-ka2-efficiency-20261029-design-r5
revision: r5
---

# Stack lock — loggerd and encoderd KA2 design

## Decision

```json
{
  "applicable": false,
  "reason": "no new runtime or framework - existing stack unchanged",
  "scope": "design-to-build",
  "decided_by": "commander"
}
```

The unchanged-stack decision carries forward to r5: the revised design adds no runtime, framework, dependency, build configuration, or third-party package. It designs a loggerd/encoderd control handshake and explicit test diagnostics on the existing C++/SCons and Python test stack; the MPP copy path remains the default. Any capability probe or benchmark runner is run-specific evidence, not a checked-in product tool.

No runtime or framework decision changed between r4 and r5. The prior runtime scan limitation remains recorded below; the detector's incomplete repository walk is not being treated as proof of an empty stack. The r5 plan and implementation spec still use only the existing SCons/native C++ and Python test stack.

## Runtime inspection

`python /data/kommu/.codex/skills/scripts/check_runtime.py --project-root /data/openpilot --detect-project` returned exit 1. It reported Python 3.12.3 below the harness minimum 3.13 and an incomplete project walk because the 10,000,000-byte inspection limit was exceeded. Its partial result says `library/CLI` and `stacks=none`, but that is not a complete repository-wide stack classification.

A narrower read-only inspection of `system/loggerd/encoder` also exceeded the total-byte limit and warned that the directory had no project evidence; it does not establish a full-repository runtime result. No package installation or environment change was made.

The no-new-runtime decision follows from the r5 plan and implementation spec, both of which add no runtime, framework, or dependency. The incomplete scanner result is recorded as a tool limitation, not as proof that the repository has no registered stack. Any later dependency or framework addition requires a new stack decision.
