# Security seed — loggerd and encoderd KA2 lossless correction (r5)

## Phase selection

- **Phase:** design
- **Return boundary:** design-to-build
- **Architecture revision:** architecture-r5
- **Owner:** security-builder

This is a forward-looking security seed for the proposed r5 design. It does not grade an implementation, claim that the handshake is feasible, or assert that any control is implemented. The exact loaded MPP/EOS and IDR behavior, VisionIPC ring and queue bounds, memory headroom, writer completion, and concurrent manager-stop drain remain gated. The current copy-mode path has failed the whole-process zero-loss requirement in two separately captured synthetic runs: the earlier run emitted 138/144 IDs per output; the corrected exact-ID run emitted 137/145. Neither is a qualifying baseline, and no performance evidence exists.

## Scope and data classification

R5 proposes a loggerd-owned PREPARE/COMMIT/STOP_DRAIN control exchange over the existing local Params store, per-service acknowledgements, and bounded input/output staging. It retains existing VisionIPC, cereal, route-file, uploader, and retention paths. Camera frames and encoded media are sensitive vehicle data; recorded audio is sensitive audio data. Frame identifiers, transaction state, queue sizes, timings, and loss counters are operational metadata. Synthetic test artifacts must contain no real media and remain under an isolated temporary root.

The proposed transaction changes the use of the existing Params boundary from one-way segment authority to a bidirectional rotation and teardown protocol. Raw frame staging and a future encoded-message FIFO extend the in-memory lifetime of camera-derived data. Test diagnostics add an isolated metadata output. These boundaries need explicit build controls even though no network recipient, manager predicate, or product code change is approved by this design package.

## Typed `security_seed`

```json
{
  "applicable": true,
  "scope": "KA2 loggerd/encoderd r5 PREPARE/COMMIT/STOP_DRAIN protocol, bounded frame/message staging, and isolated synthetic diagnostics; existing VisionIPC, cereal, persistent route-log, uploader, and manager boundaries otherwise retained",
  "decided_by": "security-builder",
  "architecture_revision": "architecture-r5",
  "reason": "R5 proposes a bidirectional shared-Params transaction protocol and new bounded in-memory retention for sensitive camera frames and encoded packets. These move the existing local process-control and data-retention boundaries and require build controls. This is a design seed only. The existing copy path failed D-16 in two synthetic runs (144 submitted/138 emitted, then 145/137); the corrected run proves neither segment-schedule correctness nor audio sample equivalence. Exact-build EOS completion, first-frame IDR, ring/queue/memory feasibility, writer completion, and the concurrent manager-stop drain remain hard gates.",
  "boundaries": [
    {
      "id": "SEC-R5-LOCAL-ROTATION-CONTROL",
      "control": "Treat Params as an existing shared local control boundary, not an authenticated channel. Use one versioned, atomically replaced request value and bounded per-service acknowledgements. Enforce a strict schema and byte limit; validate phase transition, route and process generation, transaction identity, service allowlist, monotonic old/target segment and epoch, frame-ID/count ranges, and the single CLOCK_BOOTTIME deadline. Clear or supersede task-owned stale transaction values at route start and teardown. Only loggerd may advance the committed segment. Reject malformed, stale, duplicate, out-of-order, or mismatched records and fail closed. Put no frame/audio payload in Params. An ack is not proof of media completion: loggerd must independently consume and write the exact watermarks, verify zero queues/pending work, and finalize writers before commit or successful shutdown. The assumed threat model trusts the existing local daemon set; Params cannot authenticate against an untrusted same-host writer. If that threat model changes, require a separately reviewed peer-authenticated IPC design before implementation."
    },
    {
      "id": "SEC-R5-SENSITIVE-STAGING",
      "control": "Raw NV12 staging and the proposed future encoded-message FIFO retain sensitive camera-derived data. Derive per-stream frame and byte caps using exact dimensions/strides, FPS, target ring and lease behavior, supported pause/fence horizons, loaded-MPP packet bounds, and the complete FIFO message/allocation footprint. Include current RSS and supported DMA/device-memory headroom; stop if any bound is unknown or aggregate use cannot stay below the existing 80% critical-memory abort. Never evict, overwrite, or silently drop required frames/messages to fit a cap. On cap, timeout, failed completion, or memory-preflight failure, mark the transaction failed and do not commit or claim zero loss. Release owned buffers on successful drain and every failure/cleanup path. Do not copy media payloads into diagnostics or persistent Params/log data."
    },
    {
      "id": "SEC-R5-SYNTHETIC-DIAGNOSTICS",
      "control": "Enable diagnostic sidecars only under explicit test-only flags and only for synthetic fixtures. Record IDs, counters, CLOCK_BOOTTIME timings, and queue/watermark metadata under a per-run isolated temporary root; never store camera/audio payloads or write diagnostics to production Params, rlog/qlog, persistent storage, or a new cereal/network recipient. Hash preserved failure evidence before cleanup and remove temporary artifacts through success/failure cleanup. Recheck device idleness and namespace ownership for every authorized run. Any code path that could capture real media or write outside the isolated root requires a new design/security review."
    }
  ]
}
```

## Boundary notes and residual risk

- `Params::put()` uses a temporary file, `fsync`, rename, and directory `fsync` (`common/params.cc:130-166`); the existing nonblocking writer queues separate keys asynchronously (`common/params.cc:227-241`). The design therefore uses a coherent serialized request value and per-service acknowledgement values; it does not assume that multiple keys update atomically or that `putNonBlocking()` is an immediate barrier.
- Route/process generation and transaction identity prevent stale values from satisfying a new transaction, but do not provide cryptographic authentication. The default trust model remains the existing trusted local daemon set. A broader same-host threat model needs a separate authenticated IPC decision.
- The proposed request/ack must contain only bounded metadata and IDs, never frame or audio bytes. Loggerd must validate each acknowledgement against independently observed and written watermarks. Existing timeout, queue-overflow, forced-close, empty-packet, and writer-error paths cannot be treated as benign or as evidence of successful commit.
- New staging extends the in-memory lifetime of sensitive camera data. The design has no approved capacity values yet. Exact packet-size, ring/pause, queue-representation and memory-headroom bounds are hard prerequisites; formulas or static estimates alone do not establish runtime feasibility.
- The loaded MPP API and current build/runtime mapping remain unresolved. The inspected old `/usr/lib/aarch64-linux-gnu/librockchip_mpp.so.0` hash is `ea762b7da71b63a73cdf14d053d84b091654aee5e5c4f26ceb1449b8fb8d92f9`; newer `/usr/local` headers/library are not evidence for that loaded image. Reported `ldd -r` success is symbol-resolution evidence only. EOS completion, first/target IDR behavior and exact launch-time library identity must be proven on the target before implementation proceeds.
- The 2026-10-30 02:30 run used the corrected direct-`EncodeIndex` assertion but failed D-16: 145 IDs were submitted per camera stream and only 137 unique IDs appeared in each encoded output. The failure is not attributed to a specific drop site. Segment placement came from elapsed-time rotation, not a predeclared frame-ID schedule; the direct test assertion stopped at wideRoad and other outputs were parsed offline. `ffprobe` showed H.264 and mono AAC track presence in segment 0 only; no audio sample equivalence, decoded-frame equivalence, no-stall proof, or causal per-site accounting was established. These are correctness evidence and residual-risk limits, not security clearance.
- No dependency, credential, network path, privilege transition, manager setting, uploader behavior, or retention policy is added. Existing route logs, recorded audio/video, and their recipients remain sensitive existing boundaries and must retain their current access and lifecycle behavior.

## Build review hooks

At build review, compare changed Params keys, serialization, and write order with the transaction schema above; verify stale/malformed acknowledgements fail closed and that loggerd independently verifies consumed/written watermarks before commit. Check complete frame/message cap accounting and memory headroom; ensure cap failures do not evict data. Verify sensitive buffer release on all exits and ensure diagnostic flags, roots, payload exclusion, and cleanup are enforced. Do not mark EOS, IDR, ring retention, queue feasibility, writer completion, or manager shutdown controls verified without exact-target evidence. No dependency scan, implementation check, or runtime probe is claimed in this design seed.

## Source and requirement binding

- Intake r50 `report_grilling.md`: SHA-256 `eafbf6eaf3033bc53f7661b2a4fd183f7a57904f5e77a67f04ab60ac72d78f15`.
- Intake r50 `intake-brief.md`: SHA-256 `c5dd92bfc130e339d32ac1fffda73a33235d72ba9e503da6a8f02a75f9453f6a`.
- R5 architecture: `design/reports/report_architecture.md`, SHA-256 `d4f58e8e616b211e809b1006692b7632f1d26b62ec843bf87fde5ca1408aac8a`.
- R5 interfaces: `design/reports/report_interfaces.md`, SHA-256 `c8306fb91ada0009f7ce56c430a574c8183a2f2bcbc7728516e04bbe166ccbd7`.
- R5 typed interface set: `design/artifacts/interface_set.json`, SHA-256 `20e29bfffc101ae79597273ee997a76defdad86b6962755a6bd3bfb97fceb43a`.
- R5 research: `design/reports/report_research.md`, SHA-256 `3ef28ea61975967b2f34a4a80b56e17ab481b6a488ed36cce9f60887735af04b`.
- R5 plan: `design/reports/delivery-plan.md`, SHA-256 `0376f0cea4d71bbf3f1b3ae91c6300db5afdc6a66e6f6423f4ddf44e302fcd30`.
- The security seed binds only these upstream inputs and does not bind the implementation spec. The plan does not bind the security-seed hash, preserving an acyclic dependency graph.
- Corrected-test report `build/reports/report_tests.md`: SHA-256 `09aab13bdf40308c31aafe2b9be99736dca02a2493f0ebd2524aee079e5447f9`.
- Corrected 02:30 run summary `build/evidence/rerun_20261030_023059/test_run_summary.json`: SHA-256 `3c4cd258f8b8a5f9e0f7d4c1f8d7087c0967491338d71af2b2198a97f6a75179`.
- Corrected input/output frame ledger `build/evidence/rerun_20261030_023059/frame_ledger.csv`: canonical SHA-256 `82e18f684b2b086e22d9da3f496a1bcecf5032863ee40c2b89a47d19abf6fb9a`; raw file SHA-256 `27625d6c70829ffd8fb8b46cfceaa5843d712cc3bc5ed6946598a70a6d0557c5`.
- This seed is a design-stage control statement only. It does not authorize product changes, another runtime run, or performance sampling.
