---
submission_id: loggerd-ka2-efficiency-20261029-design-r8
revision: r8
---

# Design package — KA2 rotation liveness and encoder fault containment, r8

## Outcome

This r8 package defines a bounded, stream-isolated repair for the KA2 deterministic loggerd/encoderd rotation path exposed by D-29. Full-resolution MPP remains mandatory DMA-BUF-only under D-28: validate the fd, make one MPP DMA import attempt, and drop/count a rejected frame. There is no full-resolution copy fallback, pointer retry, selector, or alternate input route. qRoad retains its existing RGA resize path.

All new liveness, readiness, reporting, writer/audio finalization, packet watchdog, and per-output recovery behavior applies only while the deterministic KA2 protocol is active: RK3588 with `ENCODERD_DETERMINISTIC_DISABLE` unset or zero, and `LOGGERD_TEST_DETERMINISTIC=1` in tests. Non-KA2 and explicitly disabled KA2 preserve pre-r8 behavior. The shared startup `logger_rotate()` remains writer-free and emits no report.

## Observed failure chain

- Loggerd's deterministic branch enters `started` at the segment boundary and waits until every configured encoder emits a next-segment packet. An MPP input rejected for lacking DMA-BUF support emits no packet, so readiness never reaches the configured count and segment 0 can persist indefinitely.
- A 900 ms MPP drain timeout can make `advance_segment_once(false)` fail; its callers currently set process-wide `do_exit`.
- Ten consecutive encoder errors and the one-second aggregate stall recovery reopen every output in the camera thread, so one road failure can churn healthy qRoad.
- `encode_frame() > 0` confirms MPP accepted a frame, not that an encoded packet was published. Empty output can leave pending identity state unresolved.
- Loggerd normally closes a stream's old writer lazily when a packet for the next segment arrives. A permanently silent stream can therefore leave an old file open after a timed rotation. qRoad audio also needs segment ownership while its delayed video writer is not open.
- Existing KA2 rotation fixtures create shared-memory VisionIPC buffers; they are correctly rejected by full-resolution no-copy MPP. The prior test stalled at segment 0 with no post-boundary frames. The DMA-heap direct-class smoke emitted 100 road and 100 qRoad packets, but did not exercise the loggerd/encoderd lifecycle.

## Chosen design

1. **Bound rotation.** In deterministic KA2 mode, commit as soon as all configured streams report a packet for the next epoch; otherwise commit at a monotonic 5,000 ms deadline from `started`, even if the service-message queue is silent. Cap the poll wake at 50 ms and the remaining deadline. This gives the qcamera's observed ≥3 s lookahead/reordering, 900 ms drain, 100 ms sync cadence, and one second of margin. The bound is for missing output; healthy streams must report readiness before it.
2. **Track readiness by epoch.** Keep a readiness set per configured stream and current rotation epoch; clear it on every commit, including degraded commits. Report the exact streams missing at a deadline in non-authoritative `LoggerdRotationReport` JSON `{route, epoch, segment, degraded, missing_streams}`. Startup emits no report.
3. **Contain encoder faults per output.** Count valid published packets as progress, not successful input submission. Track pending frame IDs and loss reasons per output. A local error, silent packet stream, or drain timeout marks/reopens only that output, with 1 s exponential backoff capped at 30 s. Drain outputs fairly under the existing shared 900 ms budget. Never set process-wide `do_exit` for one output. Reopen all outputs only when a camera/VisionIPC reconnect invalidates their buffer generation.
4. **Finalize the boundary safely.** On deterministic-KA2 runtime commits only, close every active `VideoWriter`, reset segment recording/audio/readiness state, and classify queued packets by mapped segment. Drop and count stale packets; only write matching-segment packets; keep future packets bounded. Tag qRoad audio by segment and timestamp and buffer it for at most five seconds or 256 KiB until that segment's writer opens; flush in order or drop/count at expiry. Do not create fake empty media or backfill frames. A failed track may be absent before its first keyframe or partial after writing begins.
5. **Prove both input classes.** Add a test-only C++ VisionIPC publisher using four `/dev/dma_heap/system` buffers per configured camera stream, `register_external_buffers`, explicit `DMA_BUF_IOCTL_SYNC` around CPU writes, and `send(..., sync=false)`. The full lifecycle uses isolated `LOG_ROOT`, `PARAMS_ROOT`, and `OPENPILOT_PREFIX` set before constructing Params or starting processes. Keep actual rejected SHM/invalid-fd proof, a per-output test seam if RGA cannot consume SHM, and separate silent-packet and drain-timeout fault cases.

## Segment and compatibility contract

The valid DMA-BUF arm retains existing route naming, codecs, stream selection, timestamps, sentinel placement, EncodeData/EncodeIndex ordering, segment directories, audio/front-camera behavior, and the complete healthy file set. Every submitted healthy input frame ID must appear exactly once per configured stream across startup, rotation, and shutdown; decoded pixels/audio and metadata must match.

The explicit D-28 failure arm permits loss only for the rejected/stalled output, with per-stream counts and a boundary report. Healthy qRoad remains present and decodable; missing streams do not block segment progress or stop encoderd. Late old-segment packets are dropped, and no packet or audio sample is relabeled into a later segment. The no-copy rule remains active during every error and recovery path.

New deterministic-KA2 commit and recovery semantics must not leak into non-KA2 or `ENCODERD_DETERMINISTIC_DISABLE=1` behavior. AC-12 verifies the legacy timing, writer, queue, audio, and startup behavior against pre-r8 expectations.

## Build sequence and acceptance

The delivery plan sequences the test-only DMA-BUF fixture first, per-output recovery and loggerd boundary handling second, and real loggerd+encoderd lifecycle proof after both. Its AC-1 through AC-12 cover silent-event-loop timeout, epoch reset, writer/audio finalization, actual packet progress, local error/backoff, nonfatal drain timeout, valid DMA-BUF rotations with qRoad, invalid input with qRoad, loss reporting, process/root cleanup, no-copy regression, and legacy-mode/startup compatibility.

Build acceptance requires repeated valid synthetic DMA-BUF rotations with no unexpected drops/recoveries and every healthy output ready before five seconds; invalid-input, silent-output, and drain-timeout cases must advance within the bound while healthy qRoad continues without sibling reopen. Recheck device/process activity before each board test, never stop manager/uploader/deleter or compete with active camera/MPP work, and clean all test processes, fds, mappings, temporary roots, and Params values in `finally`.

## Security, stack, and Taste

Security-builder assessed no new or moved adversarial trust boundary. The assessment is not a qualification of the live V4L2 exporter, DMA-BUF lifetime/fences, MPP driver, or kernel; bounded queues, safe frame identity retirement, local stream-name validation, and isolated test roots remain required controls. The stack is unchanged: existing C++/KA2/Mpp/RGA/VisionIPC only, no new runtime or dependency. Python 3.13.15 is available for validation, but the whole-repository runtime scan exceeds its byte limit. The on-disk hook config and referenced scripts exist and are executable; active host registration was not independently verified.

Taste resolution found no project or global preference profile (both absent at revision 0; effective profile empty). The no-profile applicability record is `artifacts/taste_snapshot_r8.json`; it was rechecked immediately before gate preparation. There is no user-facing surface, so the architect's UI applicability record uses the sanctioned no-surface value.

## Remaining limits

- The actual live RK V4L2 exporter, synchronization/fence semantics, and buffer-reuse lifetime remain unqualified by this synthetic design.
- Whether the KA2 RGA accepts the existing SHM fixture's mapped address must be checked on the target. If it does not, use the documented test-only per-output rejection seam for lifecycle containment while retaining direct actual invalid-fd/SHM MPP rejection evidence; do not claim SHM/RGA compatibility.
- Existing downstream handling of absent or partial failed-stream files must be inspected during build review before release.
- This package defines design-to-build acceptance; no product implementation or lifecycle test was run in the design phase, and it makes no CPU/RSS/latency gain claim.
