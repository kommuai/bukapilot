---
submission_id: loggerd-ka2-efficiency-20261029_handoff-5_attempt-2_2026-10-31T05-31-35Z
revision: r8
boundary: design-to-build
---

# Delivery package: KA2 rotation liveness r8

**Status:** Gatekeeper-design and gatekeeper-admiral approved r8. Build-management may begin.  
**Boundary:** DESIGN → BUILD.  
**Submission:** `loggerd-ka2-efficiency-20261029_handoff-5_attempt-2_2026-10-31T05-31-35Z`.

## Approved source of truth

- Design manifest: `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/manifest.json`
- Manifest SHA-256: `e712983e65dfeb71ddf9b72622a59208a8379800bfb87248185b0ade7424ab99`
- Design submission and revision: `loggerd-ka2-efficiency-20261029-design-r8`, `r8`
- Phase approval: `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8.json`, SHA-256 `e4b847a3022fcb15d4b605519fd2ca0e97fce4c64e59da9550f34a8243ad54f9`, verdict `APPROVED`, ID `05ed90549602c17f45e9056c5aac9d5e64ee8f3eba6d5c865a815d63ff6440f5`
- Phase judgment: `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8.judgment.json`, SHA-256 `02c67d21498947b0077b1cd5df50f17fd8b71b36f19935dbf894de557534c6b9`
- Prior cross-stage record: `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8.cross-stage.json`, SHA-256 `10e8c85af9bd7dd282c6ec5e6c35fdc6efdcf38715d85aa0bb0c8ecc0a00861e`, verdict `REVISE`, finding X-1. Its judgment SHA-256 is `74f6f180023a76dca67919dc9e674398a758cd9cfbc101fda4b47d0099980b60`.

- Corrected cross-stage approval: `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8-attempt-2.cross-stage.json`, SHA-256 `83c23b580e7b3b5883cf51a4b061b59e4e774e1ea07b7ddac93a3b36682bc80a`, verdict `APPROVED`. Its judgment SHA-256 is `75942366db77e008721d44374e6a4acdda296dd44ea496ae8f14dc32ca8d8367`.

X-1 said the delivery handoff and summary still named r7. Both active documents now identify the exact r8 manifest, phase approval, prior cross-stage review, and corrected attempt-specific approval. The prior `REVISE` is retained as history.

## Approved design scope

The r8 design repairs deterministic KA2 segment liveness and contains encoder failures while retaining D-28's mandatory no-copy path:

- Full-resolution MPP validates and imports a DMA-BUF once. Rejected input is dropped and counted. No full-resolution copy fallback, pointer retry, or mode selector is permitted. qRoad retains its existing RGA resize path.
- Loggerd commits when all configured streams are ready or at the 5,000 ms monotonic deadline, even if the message queue is silent. Readiness is per stream and epoch; poll wake is capped at 50 ms.
- Packet stalls, encoder errors, and drain timeouts recover per output with bounded retries. A failed stream cannot stop encoderd or force a healthy sibling such as qRoad to reopen.
- Deterministic runtime commits finalize active writers and keep video/audio attributed to the correct segment. qRoad audio buffering is ordered and capped at 5 seconds or 256 KiB. Startup `logger_rotate()` remains writer-free and emits no report.
- Tests use a C++ DMA-heap VisionIPC external-buffer fixture, isolated `LOG_ROOT`, `PARAMS_ROOT`, and `OPENPILOT_PREFIX`, plus separate rejected-input, silent-output, and drain-timeout cases. The valid-input arm must retain qRoad and all other configured healthy streams.
- AC-12 preserves non-KA2 and explicitly disabled KA2 legacy rotation, writer, queue, audio, and startup behavior.

The implementation sequence and full AC-1 through AC-12 are in `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/reports/delivery-plan_r8.md`. The code touchpoints and test ownership are in `design/reports/implementation-spec_r8.md`. No implementation or product test is part of this handoff correction.

## Open qualification limit

The live RK V4L2 DMA-BUF exporter, synchronization/fence semantics, and camera buffer lifetime/reuse are still unqualified. Synthetic system-DMA-heap success does not establish live-camera safety or behavior. Build evidence must preserve that distinction. Any live-source qualification requires separate scoped authorization and evidence; this design handoff makes no such claim.

## Next action

Build-management can consume the r8 plan and implementation spec. The open live-camera qualification limit remains: synthetic DMA-heap tests do not prove V4L2 DMA-BUF exporter, fence, or buffer-reuse behavior.
