---
submission_id: loggerd-ka2-efficiency-20261029_handoff-5_attempt-2_2026-10-31T05-31-35Z
revision: r8
boundary: design-to-build
package_path: skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/manifest.json
package_sha256: e712983e65dfeb71ddf9b72622a59208a8379800bfb87248185b0ade7424ab99
submission_status: VERDICT_RECORDED
verdict: APPROVED
phase_verdict: APPROVED
phase_verdict_path: skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8.json
phase_verdict_id: 05ed90549602c17f45e9056c5aac9d5e64ee8f3eba6d5c865a815d63ff6440f5
prior_cross_stage_verdict: REVISE
prior_cross_stage_verdict_path: skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8.cross-stage.json
prior_cross_stage_verdict_id: 05ed90549602c17f45e9056c5aac9d5e64ee8f3eba6d5c865a815d63ff6440f5
cross_stage_verdict: APPROVED
cross_stage_verdict_path: skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8-attempt-2.cross-stage.json
cross_stage_verdict_sha256: 83c23b580e7b3b5883cf51a4b061b59e4e774e1ea07b7ddac93a3b36682bc80a
cross_stage_verdict_id: 05ed90549602c17f45e9056c5aac9d5e64ee8f3eba6d5c865a815d63ff6440f5
---

# Admiral handoff: KA2 rotation liveness r8

## Package and approval lineage

This is the active DESIGN → BUILD handoff for the approved r8 design package. Its exact source of truth is `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/manifest.json`, SHA-256 `e712983e65dfeb71ddf9b72622a59208a8379800bfb87248185b0ade7424ab99`, submission `loggerd-ka2-efficiency-20261029-design-r8`, revision `r8`.

Gatekeeper-design approved that package. The phase record is `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8.json`, SHA-256 `e4b847a3022fcb15d4b605519fd2ca0e97fce4c64e59da9550f34a8243ad54f9`, verdict ID `05ed90549602c17f45e9056c5aac9d5e64ee8f3eba6d5c865a815d63ff6440f5`. Its judgment record is `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8.judgment.json`, SHA-256 `02c67d21498947b0077b1cd5df50f17fd8b71b36f19935dbf894de557534c6b9`.

The previous gatekeeper-admiral record is `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8.cross-stage.json`, SHA-256 `10e8c85af9bd7dd282c6ec5e6c35fdc6efdcf38715d85aa0bb0c8ecc0a00861e`, verdict `REVISE` with finding X-1. Its judgment is `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8.cross-stage.judgment.json`, SHA-256 `74f6f180023a76dca67919dc9e674398a758cd9cfbc101fda4b47d0099980b60`. X-1 found that the active delivery handoff and summary still named r7. This update names the approved r8 manifest and its phase approval in both documents, carries the prior cross-stage record, and preserves the live-camera qualification limit.

This is the new cross-stage submission, `loggerd-ka2-efficiency-20261029_handoff-5_attempt-2_2026-10-31T05-31-35Z`. Gatekeeper-admiral approved the corrected crossing after checking the r8 manifest, phase approval, and this handoff. The attempt-specific verdict is `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8-attempt-2.cross-stage.json`, SHA-256 `83c23b580e7b3b5883cf51a4b061b59e4e774e1ea07b7ddac93a3b36682bc80a`. The prior `REVISE` remains recorded as history. This handoff and summary name the approved r8 manifest and phase approval and preserve the live-camera qualification limit.

## Approved design contract

- Preserve D-28: full-resolution MPP accepts only a validated DMA-BUF fd with one MPP DMA import attempt. Rejected input is dropped and counted. There is no full-resolution copy fallback, pointer retry, or selector. qRoad keeps its existing RGA resize path.
- In deterministic KA2 only, loggerd commits when all configured streams are ready or at the monotonic 5,000 ms deadline; the deadline check works without encoder messages and poll wake is capped at 50 ms. Readiness resets each epoch.
- Encoder errors, packet stalls, and drain timeouts are isolated to one output with bounded retry. A local failure cannot exit encoderd or reopen a healthy sibling such as qRoad.
- Deterministic runtime commits finalize active writers and keep video/audio assigned to their actual segment. qRoad audio is ordered and bounded to 5 seconds or 256 KiB. Startup `logger_rotate()` stays writer-free and emits no report.
- The full lifecycle fixture uses synthetic DMA-heap-backed VisionIPC external buffers and isolated `LOG_ROOT`, `PARAMS_ROOT`, and `OPENPILOT_PREFIX`. Rejected-input, silent-output, and drain-timeout cases are separate. No full-resolution copy is reintroduced.
- AC-12 keeps non-KA2 and explicitly disabled KA2 legacy behavior unchanged.

## Qualification limit

The live V4L2 exporter, DMA-BUF synchronization/fences, and camera buffer lifetime/reuse remain unqualified. Synthetic DMA-heap results do not qualify live-camera behavior. Keep that limitation visible in build evidence and do not claim production-camera qualification; a live-source qualification requires a separate scoped decision.

## Next action

Build-management may begin from `design/reports/implementation-spec_r8.md` and `design/reports/delivery-plan_r8.md`, preserving the contract and qualification limit above.
