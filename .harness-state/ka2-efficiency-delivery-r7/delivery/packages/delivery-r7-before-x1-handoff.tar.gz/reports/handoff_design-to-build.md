---
submission_id: loggerd-ka2-efficiency-20261029_handoff-4_attempt-1_2026-10-30T16:38:44Z
revision: r7
boundary: design-to-build
package_path: skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/reports/r7/manifest.json
submission_status: VERDICT_RECORDED
verdict: APPROVED
phase_verdict: APPROVED
phase_verdict_id: e62e1310cdca4c16e9ef1d30596d12059ea3a8e0d219cf965d269584ced38bb5
cross_stage_verdict_id: e62e1310cdca4c16e9ef1d30596d12059ea3a8e0d219cf965d269584ced38bb5
---

# Admiral handoff: KA2 encoder efficiency r7

## Package and approval lineage

The design package is revision r7. Its manifest is at skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/reports/r7/manifest.json, SHA-256 d25c3feea446eea7768922e55d942ac698a1305e099e8cc113f979c9f62ec0f4.

Gatekeeper-design approved r7. The versioned phase verdict is skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r7.json, SHA-256 fd80a587c3fc03c126e10a94ea75b70e20298a8b310a05b4ab07da15ee066676, verdict ID e62e1310cdca4c16e9ef1d30596d12059ea3a8e0d219cf965d269584ced38bb5.

The prior Admiral review escalated because its delivery folder resolved outside the project and the attached handoff was outdated. The user directed a file move. The active delivery folder now physically resides inside the project at /data/openpilot/.harness-state/ka2-efficiency-delivery-r7/delivery, and the canonical delivery path resolves there.

Gatekeeper-admiral approved the r7 crossing. The versioned cross-stage verdict is skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r7.cross-stage.json, SHA-256 19ef9bfb4cf096dd71df3048ca8c4772633930593cd292e0e719b0e013e00f95. Its judgment is skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r7.cross-stage.judgment.json, SHA-256 aa1673a02b79438f2fcf6560420e7b0bd24f26d5080ed04c7872ebc65e1c0684.

Admiral execution tier: Tier 2, because this build requires implementation, focused tests, target preflight, and multiple delegated reviews.

## Approved build scope

Evaluate the existing opt-in MPP DMA-import path for full-resolution road, wideRoad, and driver streams. Keep copy mode as the default and rollback. qRoad remains the downscale/copy control. Apply immediate sticky copy fallback on an import failure before the A/B.

Build from a clean detached worktree pinned to 103d166829b3be04d735005ee83c24bd119764e2. Do not include the existing dirty checkout changes. Use synthetic input only, with isolated logs, Params, and IPC. No live camera, sensors, or on-road recording.

The comparison is best-effort: report frame loss and decode results against the matched copy arm; do not claim lossless output. Do not change codec settings, frame cadence, stream selection, routes, public interfaces, or production defaults.

## Acceptance and known limits

The source-derived estimate is 207.36 MB/s of input-copy traffic across three full-resolution streams. This is arithmetic, not a measured CPU or memory saving.

At G0, identify the exact MPP library loaded by the candidate binary. The board currently has different system and local MPP libraries, and the preflight reported CmaFree as zero. Recheck the driver, idle state, and memory headroom before any encoder run. If the target is not idle or resource headroom is insufficient, stop and report the experiment as unavailable.

The build package must include immediate same-frame copy fallback tests, sticky fallback across reopen, safe allocation/copy failure behavior, and a matched synthetic A/B with packet usability, decoded-content identity, loss, timestamps, segment mapping, CPU, RSS, and available DMA/CMA measurements.

## Next action

Build-management begins the approved single slice with G0: create a clean detached worktree pinned to 103d166829b3be04d735005ee83c24bd119764e2, identify the exact loaded MPP library, and preflight target idleness and memory headroom before implementation or encoder runs.
