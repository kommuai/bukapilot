# Delivery package: KA2 encoder efficiency r7

**Status:** Admiral cross-stage approved; build-management may begin.  
**Design revision:** r7.  
**Boundary:** design-to-build.

## Outcome

The user approved a best-effort efficiency experiment. The approved design tests the current optional MPP DMA-import path on full-resolution road, wideRoad, and driver streams. qRoad remains a control. Copy mode stays the default and rollback.

## Approved source of truth

- Design package: skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/reports/r7/manifest.json
- Design manifest SHA-256: d25c3feea446eea7768922e55d942ac698a1305e099e8cc113f979c9f62ec0f4
- Phase verdict: skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r7.json
- Phase verdict: APPROVED; verdict ID e62e1310cdca4c16e9ef1d30596d12059ea3a8e0d219cf965d269584ced38bb5
- Pinned source revision: 103d166829b3be04d735005ee83c24bd119764e2

## Scope and safeguards

The build is limited to MPP input selection and fallback in the encoder adapter, plus focused tests and a bounded synthetic comparison. Existing dirty checkout changes are excluded. The test uses isolated temporary roots and synthetic inputs. It does not use a live camera, sensors, or an on-road recording.

The experiment compares ENCODER_ZERO_COPY=0 with ENCODER_ZERO_COPY=1 on the same binary and workload. It checks output usability, decoded content, frame loss, timestamps, segment mapping, CPU, RSS, and available DMA/CMA counters. It makes no zero-loss claim and does not change codec, resolution, FPS, stream selection, route format, public interfaces, or production defaults.

The estimated 207.36 MB/s of copy traffic is source arithmetic only; no measured efficiency gain exists yet.

## Preflight items

The RK3588 board has two MPP library builds installed. The system library reports unknown version metadata; the local library reports build 0986d01 dated 2026-08-26. G0 must confirm which library the candidate executable actually loads.

The earlier read-only preflight reported CmaFree as zero. Recheck this and other MPP activity immediately before testing. Stop if the board is busy or memory headroom is inadequate.

## Next action

The r7 design-to-build crossing is approved. Build-management starts G0 by creating a clean detached worktree from the pinned source revision and checking the loaded MPP library, target idleness, and memory headroom before implementation or encoder runs.
