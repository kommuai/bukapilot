---
submission_id: loggerd-ka2-efficiency-20261029_handoff-6_attempt-1_2026-10-31T06-21-05Z
revision: r9
boundary: design-to-build
package_path: skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/manifest.json
package_sha256: f6a7e61ea1e2fae2347beaaa3f123a2ae13aaa0d6c248eee8e91c1462a20bac1
submission_status: VERDICT_RECORDED
verdict: APPROVED
phase_verdict: APPROVED
phase_verdict_path: skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r9.json
phase_verdict_sha256: 2cf3489fcd5191b78125f7886e4540fe95abb6f7682cd61bad276d0b4ed79c7b
phase_verdict_id: ffb8a3c4beadb40f90d0a087eaa9982b066448b2196d085279c2a5aa3f8d8011
prior_approved_cross_stage_verdict: APPROVED
prior_approved_cross_stage_verdict_path: skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8-attempt-2.cross-stage.json
prior_approved_cross_stage_verdict_sha256: 83c23b580e7b3b5883cf51a4b061b59e4e774e1ea07b7ddac93a3b36682bc80a
prior_approved_cross_stage_verdict_id: 05ed90549602c17f45e9056c5aac9d5e64ee8f3eba6d5c865a815d63ff6440f5
cross_stage_verdict: APPROVED
cross_stage_verdict_path: skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r9.cross-stage.json
cross_stage_verdict_sha256: ff3541635c6edff9e9539d20567516f436b20c6cfed610865e1b1053c694a7bc
cross_stage_verdict_id: ffb8a3c4beadb40f90d0a087eaa9982b066448b2196d085279c2a5aa3f8d8011
cross_stage_judgment_path: skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r9.cross-stage.judgment.json
cross_stage_judgment_sha256: 1233a03adbcca3b6412f16083d4d4753320005172d72718c03b2efd566e0a475
---

# Admiral handoff: KA2 rotation liveness r9

## Submitted design and phase approval

This DESIGN → BUILD handoff submits the exact r9 design package at `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/manifest.json`, SHA-256 `f6a7e61ea1e2fae2347beaaa3f123a2ae13aaa0d6c248eee8e91c1462a20bac1`. Its submission is `loggerd-ka2-efficiency-20261029-design-r9-report-contract`, revision `r9`.

Gatekeeper-design approved this manifest. The phase verdict is `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r9.json`, SHA-256 `2cf3489fcd5191b78125f7886e4540fe95abb6f7682cd61bad276d0b4ed79c7b`, verdict ID `ffb8a3c4beadb40f90d0a087eaa9982b066448b2196d085279c2a5aa3f8d8011`. Its judgment is `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r9.judgment.json`, SHA-256 `86e20622c58eb57d9e0065105fb5ee54828c146fe650d4776ec8ee501ddce281`.

The previous approved cross-stage record is `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8-attempt-2.cross-stage.json`, SHA-256 `83c23b580e7b3b5883cf51a4b061b59e4e774e1ea07b7ddac93a3b36682bc80a`, verdict ID `05ed90549602c17f45e9056c5aac9d5e64ee8f3eba6d5c865a815d63ff6440f5`. The earlier r8 X-1 REVISE and its correction remain in the run history.

Gatekeeper-admiral approved this r9 crossing. Its verdict is `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r9.cross-stage.json`, SHA-256 `ff3541635c6edff9e9539d20567516f436b20c6cfed610865e1b1053c694a7bc`, verdict ID `ffb8a3c4beadb40f90d0a087eaa9982b066448b2196d085279c2a5aa3f8d8011`. Its judgment is `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r9.cross-stage.judgment.json`, SHA-256 `1233a03adbcca3b6412f16083d4d4753320005172d72718c03b2efd566e0a475`.

## r9 contract for the next stage

- Preserve D-28: full-resolution MPP accepts only a validated DMA-BUF fd with one MPP DMA import attempt. Rejected input is dropped and counted. There is no full-resolution copy fallback, pointer retry, or selector. qRoad keeps its existing RGA resize path.
- In deterministic KA2 only, loggerd commits when all configured streams are ready or at the monotonic 5,000 ms deadline; the deadline check works without encoder messages and poll wake is capped at 50 ms. Readiness resets each epoch.
- Encoder errors, packet stalls, and drain timeouts are isolated to one output with bounded retry. A local failure cannot exit encoderd or reopen a healthy sibling such as qRoad.
- Deterministic runtime commits finalize active writers and attribute late/recovered video and audio to their actual segment. Startup `logger_rotate()` stays writer-free and emits no report.
- The exact `LoggerdRotationReport` contains seven top-level fields: `route`, `epoch`, `segment`, `degraded`, `missing_streams`, `elapsed_ms`, and `known_drop_counts`. The drop map has exactly five loggerd-observed counters. Encoder-side MPP rejection/stall/drain losses remain in per-output encoderd logs/counters.
- qRoad audio is FIFO and bounded to five seconds or 256 KiB. On capacity overflow, reject the newest whole event atomically, preserve older entries and ordering, and count one capacity drop.
- The full lifecycle fixture uses synthetic DMA-heap-backed VisionIPC external buffers and isolated `LOG_ROOT`, `PARAMS_ROOT`, and `OPENPILOT_PREFIX`. Rejected-input, silent-output, and drain-timeout cases are separate. No full-resolution copy is reintroduced.
- AC-12 keeps non-KA2 and explicitly disabled KA2 legacy behavior unchanged.

## Qualification limit

Live RK3588 V4L2 DMA-BUF exporter behavior, DMA-BUF synchronization and fences, MPP import against live camera buffers, and camera buffer lifetime/reuse remain unqualified. M0 proves only the isolated synthetic DMA-heap VisionIPC transport and fixture-owned buffer lifetime; it does not prove MPP import or the full loggerd/encoderd lifecycle. SHM-to-RGA compatibility and downstream handling of absent or partial stream files also remain open. Do not claim live-camera or production-camera qualification from this package.

## Gate state and next action

The r9 design phase gate and cross-stage gate are both APPROVED, and this handoff is `VERDICT_RECORDED`. Build-management may now consume `design/reports/implementation-spec_r9.md` and `design/reports/delivery-plan_r9.md`, retaining the qualification limits above. No product implementation or test work was included in this handoff update.
