---
submission_id: loggerd-ka2-efficiency-20261029_handoff-6_attempt-1_2026-10-31T06-21-05Z
revision: r9
boundary: design-to-build
---

# Delivery package: KA2 rotation liveness r9

**Status:** Design phase and cross-stage approval are recorded as approved. Build work has not started.  
**Boundary:** DESIGN → BUILD.  
**Submission:** `loggerd-ka2-efficiency-20261029_handoff-6_attempt-1_2026-10-31T06-21-05Z`.

## Approved source of truth

- Design manifest: `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/manifest.json`
- Manifest SHA-256: `f6a7e61ea1e2fae2347beaaa3f123a2ae13aaa0d6c248eee8e91c1462a20bac1`
- Design submission and revision: `loggerd-ka2-efficiency-20261029-design-r9-report-contract`, `r9`
- Phase approval: `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r9.json`, SHA-256 `2cf3489fcd5191b78125f7886e4540fe95abb6f7682cd61bad276d0b4ed79c7b`, verdict `APPROVED`, ID `ffb8a3c4beadb40f90d0a087eaa9982b066448b2196d085279c2a5aa3f8d8011`
- Phase judgment: `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r9.judgment.json`, SHA-256 `86e20622c58eb57d9e0065105fb5ee54828c146fe650d4776ec8ee501ddce281`
- Prior approved cross-stage record: `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r8-attempt-2.cross-stage.json`, SHA-256 `83c23b580e7b3b5883cf51a4b061b59e4e774e1ea07b7ddac93a3b36682bc80a`, verdict ID `05ed90549602c17f45e9056c5aac9d5e64ee8f3eba6d5c865a815d63ff6440f5`
- Cross-stage approval: `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r9.cross-stage.json`, SHA-256 `ff3541635c6edff9e9539d20567516f436b20c6cfed610865e1b1053c694a7bc`, verdict `APPROVED`, ID `ffb8a3c4beadb40f90d0a087eaa9982b066448b2196d085279c2a5aa3f8d8011`
- Cross-stage judgment: `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/verdict_design-to-build-r9.cross-stage.judgment.json`, SHA-256 `1233a03adbcca3b6412f16083d4d4753320005172d72718c03b2efd566e0a475`

The earlier r8 cross-stage X-1 REVISE and its correction are preserved in the run's design verdict history. This r9 handoff carries the new manifest and matching r9 phase approval, rather than the superseded r8 package.

## Approved design scope

The r9 design addresses deterministic KA2 segment liveness and contains encoder failures while preserving D-28's mandatory no-copy rule:

- Full-resolution MPP validates and imports a DMA-BUF once. Rejected input is dropped and counted. No full-resolution copy fallback, pointer retry, or mode selector is permitted. qRoad retains its existing RGA resize path.
- Loggerd commits when all configured streams are ready or at the monotonic 5,000 ms deadline, even if the message queue is silent. Readiness is per stream and epoch; poll wake is capped at 50 ms.
- Packet stalls, encoder errors, and drain timeouts recover per output with bounded retries. A failed stream cannot stop encoderd or force a healthy sibling such as qRoad to reopen.
- Deterministic runtime commits finalize active writers and keep video/audio attributed to the correct segment. The diagnostic `LoggerdRotationReport` has exactly seven top-level fields and exactly five loggerd-observed drop counters; it does not carry encoder-only losses or control rotation.
- qRoad audio remains FIFO and is capped at 5 seconds or 256 KiB. Capacity overflow rejects the newest whole event atomically and preserves already queued samples and ordering.
- The full lifecycle fixture uses a C++ DMA-heap VisionIPC external-buffer publisher, isolated `LOG_ROOT`, `PARAMS_ROOT`, and `OPENPILOT_PREFIX`, with separate rejected-input, silent-output, and drain-timeout cases. The valid-input arm must retain qRoad and other configured healthy streams.
- AC-12 preserves non-KA2 and explicitly disabled KA2 legacy rotation, writer, queue, audio, and startup behavior.

The implementation sequence and AC-1 through AC-12 are in `skillset-saves/runs/loggerd-ka2-efficiency-20261029/design/reports/delivery-plan_r9.md`. Code touchpoints, exact report schema and counter semantics, and test ownership are in `design/reports/implementation-spec_r9.md` and `design/reports/report_interfaces_r9.md`.

## Open qualification limit

Live RK3588 V4L2 DMA-BUF exporter behavior, synchronization/fence semantics, MPP import against live camera buffers, and camera buffer lifetime/reuse remain unqualified. The M0 synthetic DMA-heap VisionIPC fixture proves transport and fixture-owned lifetime only; it does not establish MPP import or full loggerd/encoderd lifecycle behavior. SHM-to-RGA compatibility and downstream handling of absent or partial stream files also remain open. No live-camera qualification is claimed.

## Next action

Gatekeeper-admiral approved the r9 DESIGN → BUILD crossing, and the handoff now records that verdict. Build-management may start from the r9 implementation spec and delivery plan while preserving the open qualification limit above. No build work was started as part of recording this handoff.
